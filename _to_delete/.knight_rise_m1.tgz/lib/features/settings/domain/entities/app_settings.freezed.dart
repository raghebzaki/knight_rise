// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'app_settings.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$AppSettings {

 ThemeVariant get themeVariant;/// Opt-in exact alarms on Android (Device Health screen, Milestone 3).
 bool get precisionTiming;/// Water logged per tap and per notification "Done".
 int get waterPerTapMl;
/// Create a copy of AppSettings
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$AppSettingsCopyWith<AppSettings> get copyWith => _$AppSettingsCopyWithImpl<AppSettings>(this as AppSettings, _$identity);



@override
bool operator ==(Object other) {
  final _this = this as AppSettings;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is AppSettings&&(identical(other.themeVariant, _this.themeVariant) || other.themeVariant == _this.themeVariant)&&(identical(other.precisionTiming, _this.precisionTiming) || other.precisionTiming == _this.precisionTiming)&&(identical(other.waterPerTapMl, _this.waterPerTapMl) || other.waterPerTapMl == _this.waterPerTapMl));
}


@override
int get hashCode {
  final _this = this as AppSettings;
  return Object.hash(runtimeType,_this.themeVariant,_this.precisionTiming,_this.waterPerTapMl);
}

@override
String toString() {
  final _this = this as AppSettings;
  return 'AppSettings(themeVariant: ${_this.themeVariant}, precisionTiming: ${_this.precisionTiming}, waterPerTapMl: ${_this.waterPerTapMl})';
}


}

/// @nodoc
abstract mixin class $AppSettingsCopyWith<$Res>  {
  factory $AppSettingsCopyWith(AppSettings value, $Res Function(AppSettings) _then) = _$AppSettingsCopyWithImpl;
@useResult
$Res call({
 ThemeVariant themeVariant, bool precisionTiming, int waterPerTapMl
});




}
/// @nodoc
class _$AppSettingsCopyWithImpl<$Res>
    implements $AppSettingsCopyWith<$Res> {
  _$AppSettingsCopyWithImpl(this._self, this._then);

  final AppSettings _self;
  final $Res Function(AppSettings) _then;

/// Create a copy of AppSettings
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? themeVariant = null,Object? precisionTiming = null,Object? waterPerTapMl = null,}) {
  return _then(AppSettings(
themeVariant: null == themeVariant ? _self.themeVariant : themeVariant // ignore: cast_nullable_to_non_nullable
as ThemeVariant,precisionTiming: null == precisionTiming ? _self.precisionTiming : precisionTiming // ignore: cast_nullable_to_non_nullable
as bool,waterPerTapMl: null == waterPerTapMl ? _self.waterPerTapMl : waterPerTapMl // ignore: cast_nullable_to_non_nullable
as int,
  ));
}

}


/// Adds pattern-matching-related methods to [AppSettings].
extension AppSettingsPatterns on AppSettings {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _AppSettings value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _AppSettings() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _AppSettings value)  $default,){
final _that = this;
switch (_that) {
case _AppSettings():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _AppSettings value)?  $default,){
final _that = this;
switch (_that) {
case _AppSettings() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( ThemeVariant themeVariant,  bool precisionTiming,  int waterPerTapMl)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _AppSettings() when $default != null:
return $default(_that.themeVariant,_that.precisionTiming,_that.waterPerTapMl);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( ThemeVariant themeVariant,  bool precisionTiming,  int waterPerTapMl)  $default,) {final _that = this;
switch (_that) {
case _AppSettings():
return $default(_that.themeVariant,_that.precisionTiming,_that.waterPerTapMl);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( ThemeVariant themeVariant,  bool precisionTiming,  int waterPerTapMl)?  $default,) {final _that = this;
switch (_that) {
case _AppSettings() when $default != null:
return $default(_that.themeVariant,_that.precisionTiming,_that.waterPerTapMl);case _:
  return null;

}
}

}

/// @nodoc


class _AppSettings implements AppSettings {
  const _AppSettings({this.themeVariant = ThemeVariant.midnight, this.precisionTiming = false, this.waterPerTapMl = 250});
  

@override@JsonKey() final  ThemeVariant themeVariant;
/// Opt-in exact alarms on Android (Device Health screen, Milestone 3).
@override@JsonKey() final  bool precisionTiming;
/// Water logged per tap and per notification "Done".
@override@JsonKey() final  int waterPerTapMl;

/// Create a copy of AppSettings
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$AppSettingsCopyWith<_AppSettings> get copyWith => __$AppSettingsCopyWithImpl<_AppSettings>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _AppSettings&&(identical(other.themeVariant, themeVariant) || other.themeVariant == themeVariant)&&(identical(other.precisionTiming, precisionTiming) || other.precisionTiming == precisionTiming)&&(identical(other.waterPerTapMl, waterPerTapMl) || other.waterPerTapMl == waterPerTapMl));
}


@override
int get hashCode {
    return Object.hash(runtimeType,themeVariant,precisionTiming,waterPerTapMl);
}

@override
String toString() {
    return 'AppSettings(themeVariant: $themeVariant, precisionTiming: $precisionTiming, waterPerTapMl: $waterPerTapMl)';
}


}

/// @nodoc
abstract mixin class _$AppSettingsCopyWith<$Res> implements $AppSettingsCopyWith<$Res> {
  factory _$AppSettingsCopyWith(_AppSettings value, $Res Function(_AppSettings) _then) = __$AppSettingsCopyWithImpl;
@override @useResult
$Res call({
 ThemeVariant themeVariant, bool precisionTiming, int waterPerTapMl
});




}
/// @nodoc
class __$AppSettingsCopyWithImpl<$Res>
    implements _$AppSettingsCopyWith<$Res> {
  __$AppSettingsCopyWithImpl(this._self, this._then);

  final _AppSettings _self;
  final $Res Function(_AppSettings) _then;

/// Create a copy of AppSettings
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? themeVariant = null,Object? precisionTiming = null,Object? waterPerTapMl = null,}) {
  return _then(_AppSettings(
themeVariant: null == themeVariant ? _self.themeVariant : themeVariant // ignore: cast_nullable_to_non_nullable
as ThemeVariant,precisionTiming: null == precisionTiming ? _self.precisionTiming : precisionTiming // ignore: cast_nullable_to_non_nullable
as bool,waterPerTapMl: null == waterPerTapMl ? _self.waterPerTapMl : waterPerTapMl // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

// dart format on
