// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'reminder_event.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$ReminderEvent {

 RoutineType get type; ReminderOutcome get outcome;/// When the outcome happened (completion / snooze time).
 DateTime get at; int? get id;/// The reminder slot this event resolves, when known.
 DateTime? get scheduledAt;/// Set for [ReminderOutcome.snoozed].
 DateTime? get snoozedUntil;/// Water logged with a hydration completion.
 int? get waterMl;
/// Create a copy of ReminderEvent
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$ReminderEventCopyWith<ReminderEvent> get copyWith => _$ReminderEventCopyWithImpl<ReminderEvent>(this as ReminderEvent, _$identity);



@override
bool operator ==(Object other) {
  final _this = this as ReminderEvent;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is ReminderEvent&&(identical(other.type, _this.type) || other.type == _this.type)&&(identical(other.outcome, _this.outcome) || other.outcome == _this.outcome)&&(identical(other.at, _this.at) || other.at == _this.at)&&(identical(other.id, _this.id) || other.id == _this.id)&&(identical(other.scheduledAt, _this.scheduledAt) || other.scheduledAt == _this.scheduledAt)&&(identical(other.snoozedUntil, _this.snoozedUntil) || other.snoozedUntil == _this.snoozedUntil)&&(identical(other.waterMl, _this.waterMl) || other.waterMl == _this.waterMl));
}


@override
int get hashCode {
  final _this = this as ReminderEvent;
  return Object.hash(runtimeType,_this.type,_this.outcome,_this.at,_this.id,_this.scheduledAt,_this.snoozedUntil,_this.waterMl);
}

@override
String toString() {
  final _this = this as ReminderEvent;
  return 'ReminderEvent(type: ${_this.type}, outcome: ${_this.outcome}, at: ${_this.at}, id: ${_this.id}, scheduledAt: ${_this.scheduledAt}, snoozedUntil: ${_this.snoozedUntil}, waterMl: ${_this.waterMl})';
}


}

/// @nodoc
abstract mixin class $ReminderEventCopyWith<$Res>  {
  factory $ReminderEventCopyWith(ReminderEvent value, $Res Function(ReminderEvent) _then) = _$ReminderEventCopyWithImpl;
@useResult
$Res call({
 RoutineType type, ReminderOutcome outcome, DateTime at, int? id, DateTime? scheduledAt, DateTime? snoozedUntil, int? waterMl
});




}
/// @nodoc
class _$ReminderEventCopyWithImpl<$Res>
    implements $ReminderEventCopyWith<$Res> {
  _$ReminderEventCopyWithImpl(this._self, this._then);

  final ReminderEvent _self;
  final $Res Function(ReminderEvent) _then;

/// Create a copy of ReminderEvent
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? type = null,Object? outcome = null,Object? at = null,Object? id = freezed,Object? scheduledAt = freezed,Object? snoozedUntil = freezed,Object? waterMl = freezed,}) {
  return _then(ReminderEvent(
type: null == type ? _self.type : type // ignore: cast_nullable_to_non_nullable
as RoutineType,outcome: null == outcome ? _self.outcome : outcome // ignore: cast_nullable_to_non_nullable
as ReminderOutcome,at: null == at ? _self.at : at // ignore: cast_nullable_to_non_nullable
as DateTime,id: freezed == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as int?,scheduledAt: freezed == scheduledAt ? _self.scheduledAt : scheduledAt // ignore: cast_nullable_to_non_nullable
as DateTime?,snoozedUntil: freezed == snoozedUntil ? _self.snoozedUntil : snoozedUntil // ignore: cast_nullable_to_non_nullable
as DateTime?,waterMl: freezed == waterMl ? _self.waterMl : waterMl // ignore: cast_nullable_to_non_nullable
as int?,
  ));
}

}


/// Adds pattern-matching-related methods to [ReminderEvent].
extension ReminderEventPatterns on ReminderEvent {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _ReminderEvent value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _ReminderEvent() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _ReminderEvent value)  $default,){
final _that = this;
switch (_that) {
case _ReminderEvent():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _ReminderEvent value)?  $default,){
final _that = this;
switch (_that) {
case _ReminderEvent() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( RoutineType type,  ReminderOutcome outcome,  DateTime at,  int? id,  DateTime? scheduledAt,  DateTime? snoozedUntil,  int? waterMl)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _ReminderEvent() when $default != null:
return $default(_that.type,_that.outcome,_that.at,_that.id,_that.scheduledAt,_that.snoozedUntil,_that.waterMl);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( RoutineType type,  ReminderOutcome outcome,  DateTime at,  int? id,  DateTime? scheduledAt,  DateTime? snoozedUntil,  int? waterMl)  $default,) {final _that = this;
switch (_that) {
case _ReminderEvent():
return $default(_that.type,_that.outcome,_that.at,_that.id,_that.scheduledAt,_that.snoozedUntil,_that.waterMl);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( RoutineType type,  ReminderOutcome outcome,  DateTime at,  int? id,  DateTime? scheduledAt,  DateTime? snoozedUntil,  int? waterMl)?  $default,) {final _that = this;
switch (_that) {
case _ReminderEvent() when $default != null:
return $default(_that.type,_that.outcome,_that.at,_that.id,_that.scheduledAt,_that.snoozedUntil,_that.waterMl);case _:
  return null;

}
}

}

/// @nodoc


class _ReminderEvent implements ReminderEvent {
  const _ReminderEvent({required this.type, required this.outcome, required this.at, this.id, this.scheduledAt, this.snoozedUntil, this.waterMl});
  

@override final  RoutineType type;
@override final  ReminderOutcome outcome;
/// When the outcome happened (completion / snooze time).
@override final  DateTime at;
@override final  int? id;
/// The reminder slot this event resolves, when known.
@override final  DateTime? scheduledAt;
/// Set for [ReminderOutcome.snoozed].
@override final  DateTime? snoozedUntil;
/// Water logged with a hydration completion.
@override final  int? waterMl;

/// Create a copy of ReminderEvent
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$ReminderEventCopyWith<_ReminderEvent> get copyWith => __$ReminderEventCopyWithImpl<_ReminderEvent>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _ReminderEvent&&(identical(other.type, type) || other.type == type)&&(identical(other.outcome, outcome) || other.outcome == outcome)&&(identical(other.at, at) || other.at == at)&&(identical(other.id, id) || other.id == id)&&(identical(other.scheduledAt, scheduledAt) || other.scheduledAt == scheduledAt)&&(identical(other.snoozedUntil, snoozedUntil) || other.snoozedUntil == snoozedUntil)&&(identical(other.waterMl, waterMl) || other.waterMl == waterMl));
}


@override
int get hashCode {
    return Object.hash(runtimeType,type,outcome,at,id,scheduledAt,snoozedUntil,waterMl);
}

@override
String toString() {
    return 'ReminderEvent(type: $type, outcome: $outcome, at: $at, id: $id, scheduledAt: $scheduledAt, snoozedUntil: $snoozedUntil, waterMl: $waterMl)';
}


}

/// @nodoc
abstract mixin class _$ReminderEventCopyWith<$Res> implements $ReminderEventCopyWith<$Res> {
  factory _$ReminderEventCopyWith(_ReminderEvent value, $Res Function(_ReminderEvent) _then) = __$ReminderEventCopyWithImpl;
@override @useResult
$Res call({
 RoutineType type, ReminderOutcome outcome, DateTime at, int? id, DateTime? scheduledAt, DateTime? snoozedUntil, int? waterMl
});




}
/// @nodoc
class __$ReminderEventCopyWithImpl<$Res>
    implements _$ReminderEventCopyWith<$Res> {
  __$ReminderEventCopyWithImpl(this._self, this._then);

  final _ReminderEvent _self;
  final $Res Function(_ReminderEvent) _then;

/// Create a copy of ReminderEvent
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? type = null,Object? outcome = null,Object? at = null,Object? id = freezed,Object? scheduledAt = freezed,Object? snoozedUntil = freezed,Object? waterMl = freezed,}) {
  return _then(_ReminderEvent(
type: null == type ? _self.type : type // ignore: cast_nullable_to_non_nullable
as RoutineType,outcome: null == outcome ? _self.outcome : outcome // ignore: cast_nullable_to_non_nullable
as ReminderOutcome,at: null == at ? _self.at : at // ignore: cast_nullable_to_non_nullable
as DateTime,id: freezed == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as int?,scheduledAt: freezed == scheduledAt ? _self.scheduledAt : scheduledAt // ignore: cast_nullable_to_non_nullable
as DateTime?,snoozedUntil: freezed == snoozedUntil ? _self.snoozedUntil : snoozedUntil // ignore: cast_nullable_to_non_nullable
as DateTime?,waterMl: freezed == waterMl ? _self.waterMl : waterMl // ignore: cast_nullable_to_non_nullable
as int?,
  ));
}


}

// dart format on
