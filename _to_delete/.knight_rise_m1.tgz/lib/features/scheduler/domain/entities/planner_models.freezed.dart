// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'planner_models.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$RoutineHistory {

 DateTime? get lastDoneAt; DateTime? get snoozedUntil; int get snoozesSinceDone;
/// Create a copy of RoutineHistory
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$RoutineHistoryCopyWith<RoutineHistory> get copyWith => _$RoutineHistoryCopyWithImpl<RoutineHistory>(this as RoutineHistory, _$identity);



@override
bool operator ==(Object other) {
  final _this = this as RoutineHistory;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is RoutineHistory&&(identical(other.lastDoneAt, _this.lastDoneAt) || other.lastDoneAt == _this.lastDoneAt)&&(identical(other.snoozedUntil, _this.snoozedUntil) || other.snoozedUntil == _this.snoozedUntil)&&(identical(other.snoozesSinceDone, _this.snoozesSinceDone) || other.snoozesSinceDone == _this.snoozesSinceDone));
}


@override
int get hashCode {
  final _this = this as RoutineHistory;
  return Object.hash(runtimeType,_this.lastDoneAt,_this.snoozedUntil,_this.snoozesSinceDone);
}

@override
String toString() {
  final _this = this as RoutineHistory;
  return 'RoutineHistory(lastDoneAt: ${_this.lastDoneAt}, snoozedUntil: ${_this.snoozedUntil}, snoozesSinceDone: ${_this.snoozesSinceDone})';
}


}

/// @nodoc
abstract mixin class $RoutineHistoryCopyWith<$Res>  {
  factory $RoutineHistoryCopyWith(RoutineHistory value, $Res Function(RoutineHistory) _then) = _$RoutineHistoryCopyWithImpl;
@useResult
$Res call({
 DateTime? lastDoneAt, DateTime? snoozedUntil, int snoozesSinceDone
});




}
/// @nodoc
class _$RoutineHistoryCopyWithImpl<$Res>
    implements $RoutineHistoryCopyWith<$Res> {
  _$RoutineHistoryCopyWithImpl(this._self, this._then);

  final RoutineHistory _self;
  final $Res Function(RoutineHistory) _then;

/// Create a copy of RoutineHistory
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? lastDoneAt = freezed,Object? snoozedUntil = freezed,Object? snoozesSinceDone = null,}) {
  return _then(RoutineHistory(
lastDoneAt: freezed == lastDoneAt ? _self.lastDoneAt : lastDoneAt // ignore: cast_nullable_to_non_nullable
as DateTime?,snoozedUntil: freezed == snoozedUntil ? _self.snoozedUntil : snoozedUntil // ignore: cast_nullable_to_non_nullable
as DateTime?,snoozesSinceDone: null == snoozesSinceDone ? _self.snoozesSinceDone : snoozesSinceDone // ignore: cast_nullable_to_non_nullable
as int,
  ));
}

}


/// Adds pattern-matching-related methods to [RoutineHistory].
extension RoutineHistoryPatterns on RoutineHistory {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _RoutineHistory value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _RoutineHistory() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _RoutineHistory value)  $default,){
final _that = this;
switch (_that) {
case _RoutineHistory():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _RoutineHistory value)?  $default,){
final _that = this;
switch (_that) {
case _RoutineHistory() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( DateTime? lastDoneAt,  DateTime? snoozedUntil,  int snoozesSinceDone)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _RoutineHistory() when $default != null:
return $default(_that.lastDoneAt,_that.snoozedUntil,_that.snoozesSinceDone);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( DateTime? lastDoneAt,  DateTime? snoozedUntil,  int snoozesSinceDone)  $default,) {final _that = this;
switch (_that) {
case _RoutineHistory():
return $default(_that.lastDoneAt,_that.snoozedUntil,_that.snoozesSinceDone);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( DateTime? lastDoneAt,  DateTime? snoozedUntil,  int snoozesSinceDone)?  $default,) {final _that = this;
switch (_that) {
case _RoutineHistory() when $default != null:
return $default(_that.lastDoneAt,_that.snoozedUntil,_that.snoozesSinceDone);case _:
  return null;

}
}

}

/// @nodoc


class _RoutineHistory implements RoutineHistory {
  const _RoutineHistory({this.lastDoneAt, this.snoozedUntil, this.snoozesSinceDone = 0});
  

@override final  DateTime? lastDoneAt;
@override final  DateTime? snoozedUntil;
@override@JsonKey() final  int snoozesSinceDone;

/// Create a copy of RoutineHistory
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$RoutineHistoryCopyWith<_RoutineHistory> get copyWith => __$RoutineHistoryCopyWithImpl<_RoutineHistory>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _RoutineHistory&&(identical(other.lastDoneAt, lastDoneAt) || other.lastDoneAt == lastDoneAt)&&(identical(other.snoozedUntil, snoozedUntil) || other.snoozedUntil == snoozedUntil)&&(identical(other.snoozesSinceDone, snoozesSinceDone) || other.snoozesSinceDone == snoozesSinceDone));
}


@override
int get hashCode {
    return Object.hash(runtimeType,lastDoneAt,snoozedUntil,snoozesSinceDone);
}

@override
String toString() {
    return 'RoutineHistory(lastDoneAt: $lastDoneAt, snoozedUntil: $snoozedUntil, snoozesSinceDone: $snoozesSinceDone)';
}


}

/// @nodoc
abstract mixin class _$RoutineHistoryCopyWith<$Res> implements $RoutineHistoryCopyWith<$Res> {
  factory _$RoutineHistoryCopyWith(_RoutineHistory value, $Res Function(_RoutineHistory) _then) = __$RoutineHistoryCopyWithImpl;
@override @useResult
$Res call({
 DateTime? lastDoneAt, DateTime? snoozedUntil, int snoozesSinceDone
});




}
/// @nodoc
class __$RoutineHistoryCopyWithImpl<$Res>
    implements _$RoutineHistoryCopyWith<$Res> {
  __$RoutineHistoryCopyWithImpl(this._self, this._then);

  final _RoutineHistory _self;
  final $Res Function(_RoutineHistory) _then;

/// Create a copy of RoutineHistory
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? lastDoneAt = freezed,Object? snoozedUntil = freezed,Object? snoozesSinceDone = null,}) {
  return _then(_RoutineHistory(
lastDoneAt: freezed == lastDoneAt ? _self.lastDoneAt : lastDoneAt // ignore: cast_nullable_to_non_nullable
as DateTime?,snoozedUntil: freezed == snoozedUntil ? _self.snoozedUntil : snoozedUntil // ignore: cast_nullable_to_non_nullable
as DateTime?,snoozesSinceDone: null == snoozesSinceDone ? _self.snoozesSinceDone : snoozesSinceDone // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

// dart format on
