// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'cycle_snapshot.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$RoutineView {

 Routine get routine; RoutineStatus get status; int get doneToday; bool get canSnooze;
/// Create a copy of RoutineView
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$RoutineViewCopyWith<RoutineView> get copyWith => _$RoutineViewCopyWithImpl<RoutineView>(this as RoutineView, _$identity);



@override
bool operator ==(Object other) {
  final _this = this as RoutineView;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is RoutineView&&(identical(other.routine, _this.routine) || other.routine == _this.routine)&&(identical(other.status, _this.status) || other.status == _this.status)&&(identical(other.doneToday, _this.doneToday) || other.doneToday == _this.doneToday)&&(identical(other.canSnooze, _this.canSnooze) || other.canSnooze == _this.canSnooze));
}


@override
int get hashCode {
  final _this = this as RoutineView;
  return Object.hash(runtimeType,_this.routine,_this.status,_this.doneToday,_this.canSnooze);
}

@override
String toString() {
  final _this = this as RoutineView;
  return 'RoutineView(routine: ${_this.routine}, status: ${_this.status}, doneToday: ${_this.doneToday}, canSnooze: ${_this.canSnooze})';
}


}

/// @nodoc
abstract mixin class $RoutineViewCopyWith<$Res>  {
  factory $RoutineViewCopyWith(RoutineView value, $Res Function(RoutineView) _then) = _$RoutineViewCopyWithImpl;
@useResult
$Res call({
 Routine routine, RoutineStatus status, int doneToday, bool canSnooze
});


$RoutineCopyWith<$Res> get routine;

}
/// @nodoc
class _$RoutineViewCopyWithImpl<$Res>
    implements $RoutineViewCopyWith<$Res> {
  _$RoutineViewCopyWithImpl(this._self, this._then);

  final RoutineView _self;
  final $Res Function(RoutineView) _then;

/// Create a copy of RoutineView
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? routine = null,Object? status = null,Object? doneToday = null,Object? canSnooze = null,}) {
  return _then(RoutineView(
routine: null == routine ? _self.routine : routine // ignore: cast_nullable_to_non_nullable
as Routine,status: null == status ? _self.status : status // ignore: cast_nullable_to_non_nullable
as RoutineStatus,doneToday: null == doneToday ? _self.doneToday : doneToday // ignore: cast_nullable_to_non_nullable
as int,canSnooze: null == canSnooze ? _self.canSnooze : canSnooze // ignore: cast_nullable_to_non_nullable
as bool,
  ));
}
/// Create a copy of RoutineView
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$RoutineCopyWith<$Res> get routine {
  
  return $RoutineCopyWith<$Res>(_self.routine, (value) {
    return _then(_self.copyWith(routine: value));
  });
}
}


/// Adds pattern-matching-related methods to [RoutineView].
extension RoutineViewPatterns on RoutineView {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _RoutineView value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _RoutineView() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _RoutineView value)  $default,){
final _that = this;
switch (_that) {
case _RoutineView():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _RoutineView value)?  $default,){
final _that = this;
switch (_that) {
case _RoutineView() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( Routine routine,  RoutineStatus status,  int doneToday,  bool canSnooze)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _RoutineView() when $default != null:
return $default(_that.routine,_that.status,_that.doneToday,_that.canSnooze);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( Routine routine,  RoutineStatus status,  int doneToday,  bool canSnooze)  $default,) {final _that = this;
switch (_that) {
case _RoutineView():
return $default(_that.routine,_that.status,_that.doneToday,_that.canSnooze);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( Routine routine,  RoutineStatus status,  int doneToday,  bool canSnooze)?  $default,) {final _that = this;
switch (_that) {
case _RoutineView() when $default != null:
return $default(_that.routine,_that.status,_that.doneToday,_that.canSnooze);case _:
  return null;

}
}

}

/// @nodoc


class _RoutineView extends RoutineView {
  const _RoutineView({required this.routine, required this.status, required this.doneToday, required this.canSnooze}): super._();
  

@override final  Routine routine;
@override final  RoutineStatus status;
@override final  int doneToday;
@override final  bool canSnooze;

/// Create a copy of RoutineView
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$RoutineViewCopyWith<_RoutineView> get copyWith => __$RoutineViewCopyWithImpl<_RoutineView>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _RoutineView&&(identical(other.routine, routine) || other.routine == routine)&&(identical(other.status, status) || other.status == status)&&(identical(other.doneToday, doneToday) || other.doneToday == doneToday)&&(identical(other.canSnooze, canSnooze) || other.canSnooze == canSnooze));
}


@override
int get hashCode {
    return Object.hash(runtimeType,routine,status,doneToday,canSnooze);
}

@override
String toString() {
    return 'RoutineView(routine: $routine, status: $status, doneToday: $doneToday, canSnooze: $canSnooze)';
}


}

/// @nodoc
abstract mixin class _$RoutineViewCopyWith<$Res> implements $RoutineViewCopyWith<$Res> {
  factory _$RoutineViewCopyWith(_RoutineView value, $Res Function(_RoutineView) _then) = __$RoutineViewCopyWithImpl;
@override @useResult
$Res call({
 Routine routine, RoutineStatus status, int doneToday, bool canSnooze
});


@override $RoutineCopyWith<$Res> get routine;

}
/// @nodoc
class __$RoutineViewCopyWithImpl<$Res>
    implements _$RoutineViewCopyWith<$Res> {
  __$RoutineViewCopyWithImpl(this._self, this._then);

  final _RoutineView _self;
  final $Res Function(_RoutineView) _then;

/// Create a copy of RoutineView
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? routine = null,Object? status = null,Object? doneToday = null,Object? canSnooze = null,}) {
  return _then(_RoutineView(
routine: null == routine ? _self.routine : routine // ignore: cast_nullable_to_non_nullable
as Routine,status: null == status ? _self.status : status // ignore: cast_nullable_to_non_nullable
as RoutineStatus,doneToday: null == doneToday ? _self.doneToday : doneToday // ignore: cast_nullable_to_non_nullable
as int,canSnooze: null == canSnooze ? _self.canSnooze : canSnooze // ignore: cast_nullable_to_non_nullable
as bool,
  ));
}

/// Create a copy of RoutineView
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$RoutineCopyWith<$Res> get routine {
  
  return $RoutineCopyWith<$Res>(_self.routine, (value) {
    return _then(_self.copyWith(routine: value));
  });
}
}

/// @nodoc
mixin _$CycleSnapshot {

 DateTime get computedAt; List<RoutineView> get routines; bool get onDuty; int get waterMlToday; int get waterTargetMl; DateTime get nextChangeAt; PlannedReminder? get nextUp; DateTime? get nextWorkStart;
/// Create a copy of CycleSnapshot
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$CycleSnapshotCopyWith<CycleSnapshot> get copyWith => _$CycleSnapshotCopyWithImpl<CycleSnapshot>(this as CycleSnapshot, _$identity);



@override
bool operator ==(Object other) {
  final _this = this as CycleSnapshot;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is CycleSnapshot&&(identical(other.computedAt, _this.computedAt) || other.computedAt == _this.computedAt)&&const DeepCollectionEquality().equals(other.routines, _this.routines)&&(identical(other.onDuty, _this.onDuty) || other.onDuty == _this.onDuty)&&(identical(other.waterMlToday, _this.waterMlToday) || other.waterMlToday == _this.waterMlToday)&&(identical(other.waterTargetMl, _this.waterTargetMl) || other.waterTargetMl == _this.waterTargetMl)&&(identical(other.nextChangeAt, _this.nextChangeAt) || other.nextChangeAt == _this.nextChangeAt)&&(identical(other.nextUp, _this.nextUp) || other.nextUp == _this.nextUp)&&(identical(other.nextWorkStart, _this.nextWorkStart) || other.nextWorkStart == _this.nextWorkStart));
}


@override
int get hashCode {
  final _this = this as CycleSnapshot;
  return Object.hash(runtimeType,_this.computedAt,const DeepCollectionEquality().hash(_this.routines),_this.onDuty,_this.waterMlToday,_this.waterTargetMl,_this.nextChangeAt,_this.nextUp,_this.nextWorkStart);
}

@override
String toString() {
  final _this = this as CycleSnapshot;
  return 'CycleSnapshot(computedAt: ${_this.computedAt}, routines: ${_this.routines}, onDuty: ${_this.onDuty}, waterMlToday: ${_this.waterMlToday}, waterTargetMl: ${_this.waterTargetMl}, nextChangeAt: ${_this.nextChangeAt}, nextUp: ${_this.nextUp}, nextWorkStart: ${_this.nextWorkStart})';
}


}

/// @nodoc
abstract mixin class $CycleSnapshotCopyWith<$Res>  {
  factory $CycleSnapshotCopyWith(CycleSnapshot value, $Res Function(CycleSnapshot) _then) = _$CycleSnapshotCopyWithImpl;
@useResult
$Res call({
 DateTime computedAt, List<RoutineView> routines, bool onDuty, int waterMlToday, int waterTargetMl, DateTime nextChangeAt, PlannedReminder? nextUp, DateTime? nextWorkStart
});




}
/// @nodoc
class _$CycleSnapshotCopyWithImpl<$Res>
    implements $CycleSnapshotCopyWith<$Res> {
  _$CycleSnapshotCopyWithImpl(this._self, this._then);

  final CycleSnapshot _self;
  final $Res Function(CycleSnapshot) _then;

/// Create a copy of CycleSnapshot
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? computedAt = null,Object? routines = null,Object? onDuty = null,Object? waterMlToday = null,Object? waterTargetMl = null,Object? nextChangeAt = null,Object? nextUp = freezed,Object? nextWorkStart = freezed,}) {
  return _then(CycleSnapshot(
computedAt: null == computedAt ? _self.computedAt : computedAt // ignore: cast_nullable_to_non_nullable
as DateTime,routines: null == routines ? _self.routines : routines // ignore: cast_nullable_to_non_nullable
as List<RoutineView>,onDuty: null == onDuty ? _self.onDuty : onDuty // ignore: cast_nullable_to_non_nullable
as bool,waterMlToday: null == waterMlToday ? _self.waterMlToday : waterMlToday // ignore: cast_nullable_to_non_nullable
as int,waterTargetMl: null == waterTargetMl ? _self.waterTargetMl : waterTargetMl // ignore: cast_nullable_to_non_nullable
as int,nextChangeAt: null == nextChangeAt ? _self.nextChangeAt : nextChangeAt // ignore: cast_nullable_to_non_nullable
as DateTime,nextUp: freezed == nextUp ? _self.nextUp : nextUp // ignore: cast_nullable_to_non_nullable
as PlannedReminder?,nextWorkStart: freezed == nextWorkStart ? _self.nextWorkStart : nextWorkStart // ignore: cast_nullable_to_non_nullable
as DateTime?,
  ));
}

}


/// Adds pattern-matching-related methods to [CycleSnapshot].
extension CycleSnapshotPatterns on CycleSnapshot {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _CycleSnapshot value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _CycleSnapshot() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _CycleSnapshot value)  $default,){
final _that = this;
switch (_that) {
case _CycleSnapshot():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _CycleSnapshot value)?  $default,){
final _that = this;
switch (_that) {
case _CycleSnapshot() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( DateTime computedAt,  List<RoutineView> routines,  bool onDuty,  int waterMlToday,  int waterTargetMl,  DateTime nextChangeAt,  PlannedReminder? nextUp,  DateTime? nextWorkStart)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _CycleSnapshot() when $default != null:
return $default(_that.computedAt,_that.routines,_that.onDuty,_that.waterMlToday,_that.waterTargetMl,_that.nextChangeAt,_that.nextUp,_that.nextWorkStart);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( DateTime computedAt,  List<RoutineView> routines,  bool onDuty,  int waterMlToday,  int waterTargetMl,  DateTime nextChangeAt,  PlannedReminder? nextUp,  DateTime? nextWorkStart)  $default,) {final _that = this;
switch (_that) {
case _CycleSnapshot():
return $default(_that.computedAt,_that.routines,_that.onDuty,_that.waterMlToday,_that.waterTargetMl,_that.nextChangeAt,_that.nextUp,_that.nextWorkStart);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( DateTime computedAt,  List<RoutineView> routines,  bool onDuty,  int waterMlToday,  int waterTargetMl,  DateTime nextChangeAt,  PlannedReminder? nextUp,  DateTime? nextWorkStart)?  $default,) {final _that = this;
switch (_that) {
case _CycleSnapshot() when $default != null:
return $default(_that.computedAt,_that.routines,_that.onDuty,_that.waterMlToday,_that.waterTargetMl,_that.nextChangeAt,_that.nextUp,_that.nextWorkStart);case _:
  return null;

}
}

}

/// @nodoc


class _CycleSnapshot extends CycleSnapshot {
  const _CycleSnapshot({required this.computedAt, required  List<RoutineView> routines, required this.onDuty, required this.waterMlToday, required this.waterTargetMl, required this.nextChangeAt, this.nextUp, this.nextWorkStart}): _routines = routines,super._();
  

@override final  DateTime computedAt;
 final  List<RoutineView> _routines;
@override List<RoutineView> get routines {
  if (_routines is EqualUnmodifiableListView) return _routines;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_routines);
}

@override final  bool onDuty;
@override final  int waterMlToday;
@override final  int waterTargetMl;
@override final  DateTime nextChangeAt;
@override final  PlannedReminder? nextUp;
@override final  DateTime? nextWorkStart;

/// Create a copy of CycleSnapshot
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$CycleSnapshotCopyWith<_CycleSnapshot> get copyWith => __$CycleSnapshotCopyWithImpl<_CycleSnapshot>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _CycleSnapshot&&(identical(other.computedAt, computedAt) || other.computedAt == computedAt)&&const DeepCollectionEquality().equals(other.routines, _routines)&&(identical(other.onDuty, onDuty) || other.onDuty == onDuty)&&(identical(other.waterMlToday, waterMlToday) || other.waterMlToday == waterMlToday)&&(identical(other.waterTargetMl, waterTargetMl) || other.waterTargetMl == waterTargetMl)&&(identical(other.nextChangeAt, nextChangeAt) || other.nextChangeAt == nextChangeAt)&&(identical(other.nextUp, nextUp) || other.nextUp == nextUp)&&(identical(other.nextWorkStart, nextWorkStart) || other.nextWorkStart == nextWorkStart));
}


@override
int get hashCode {
    return Object.hash(runtimeType,computedAt,const DeepCollectionEquality().hash(_routines),onDuty,waterMlToday,waterTargetMl,nextChangeAt,nextUp,nextWorkStart);
}

@override
String toString() {
    return 'CycleSnapshot(computedAt: $computedAt, routines: $routines, onDuty: $onDuty, waterMlToday: $waterMlToday, waterTargetMl: $waterTargetMl, nextChangeAt: $nextChangeAt, nextUp: $nextUp, nextWorkStart: $nextWorkStart)';
}


}

/// @nodoc
abstract mixin class _$CycleSnapshotCopyWith<$Res> implements $CycleSnapshotCopyWith<$Res> {
  factory _$CycleSnapshotCopyWith(_CycleSnapshot value, $Res Function(_CycleSnapshot) _then) = __$CycleSnapshotCopyWithImpl;
@override @useResult
$Res call({
 DateTime computedAt, List<RoutineView> routines, bool onDuty, int waterMlToday, int waterTargetMl, DateTime nextChangeAt, PlannedReminder? nextUp, DateTime? nextWorkStart
});




}
/// @nodoc
class __$CycleSnapshotCopyWithImpl<$Res>
    implements _$CycleSnapshotCopyWith<$Res> {
  __$CycleSnapshotCopyWithImpl(this._self, this._then);

  final _CycleSnapshot _self;
  final $Res Function(_CycleSnapshot) _then;

/// Create a copy of CycleSnapshot
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? computedAt = null,Object? routines = null,Object? onDuty = null,Object? waterMlToday = null,Object? waterTargetMl = null,Object? nextChangeAt = null,Object? nextUp = freezed,Object? nextWorkStart = freezed,}) {
  return _then(_CycleSnapshot(
computedAt: null == computedAt ? _self.computedAt : computedAt // ignore: cast_nullable_to_non_nullable
as DateTime,routines: null == routines ? _self._routines : routines // ignore: cast_nullable_to_non_nullable
as List<RoutineView>,onDuty: null == onDuty ? _self.onDuty : onDuty // ignore: cast_nullable_to_non_nullable
as bool,waterMlToday: null == waterMlToday ? _self.waterMlToday : waterMlToday // ignore: cast_nullable_to_non_nullable
as int,waterTargetMl: null == waterTargetMl ? _self.waterTargetMl : waterTargetMl // ignore: cast_nullable_to_non_nullable
as int,nextChangeAt: null == nextChangeAt ? _self.nextChangeAt : nextChangeAt // ignore: cast_nullable_to_non_nullable
as DateTime,nextUp: freezed == nextUp ? _self.nextUp : nextUp // ignore: cast_nullable_to_non_nullable
as PlannedReminder?,nextWorkStart: freezed == nextWorkStart ? _self.nextWorkStart : nextWorkStart // ignore: cast_nullable_to_non_nullable
as DateTime?,
  ));
}


}

// dart format on
