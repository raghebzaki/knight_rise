// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'cycle_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$CycleState {

 CycleStatus get status; CycleSnapshot? get snapshot; String? get error;
/// Create a copy of CycleState
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$CycleStateCopyWith<CycleState> get copyWith => _$CycleStateCopyWithImpl<CycleState>(this as CycleState, _$identity);



@override
bool operator ==(Object other) {
  final _this = this as CycleState;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is CycleState&&(identical(other.status, _this.status) || other.status == _this.status)&&(identical(other.snapshot, _this.snapshot) || other.snapshot == _this.snapshot)&&(identical(other.error, _this.error) || other.error == _this.error));
}


@override
int get hashCode {
  final _this = this as CycleState;
  return Object.hash(runtimeType,_this.status,_this.snapshot,_this.error);
}

@override
String toString() {
  final _this = this as CycleState;
  return 'CycleState(status: ${_this.status}, snapshot: ${_this.snapshot}, error: ${_this.error})';
}


}

/// @nodoc
abstract mixin class $CycleStateCopyWith<$Res>  {
  factory $CycleStateCopyWith(CycleState value, $Res Function(CycleState) _then) = _$CycleStateCopyWithImpl;
@useResult
$Res call({
 CycleStatus status, CycleSnapshot? snapshot, String? error
});


$CycleSnapshotCopyWith<$Res>? get snapshot;

}
/// @nodoc
class _$CycleStateCopyWithImpl<$Res>
    implements $CycleStateCopyWith<$Res> {
  _$CycleStateCopyWithImpl(this._self, this._then);

  final CycleState _self;
  final $Res Function(CycleState) _then;

/// Create a copy of CycleState
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? status = null,Object? snapshot = freezed,Object? error = freezed,}) {
  return _then(CycleState(
status: null == status ? _self.status : status // ignore: cast_nullable_to_non_nullable
as CycleStatus,snapshot: freezed == snapshot ? _self.snapshot : snapshot // ignore: cast_nullable_to_non_nullable
as CycleSnapshot?,error: freezed == error ? _self.error : error // ignore: cast_nullable_to_non_nullable
as String?,
  ));
}
/// Create a copy of CycleState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$CycleSnapshotCopyWith<$Res>? get snapshot {
    if (_self.snapshot == null) {
    return null;
  }

  return $CycleSnapshotCopyWith<$Res>(_self.snapshot!, (value) {
    return _then(_self.copyWith(snapshot: value));
  });
}
}


/// Adds pattern-matching-related methods to [CycleState].
extension CycleStatePatterns on CycleState {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _CycleState value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _CycleState() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _CycleState value)  $default,){
final _that = this;
switch (_that) {
case _CycleState():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _CycleState value)?  $default,){
final _that = this;
switch (_that) {
case _CycleState() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( CycleStatus status,  CycleSnapshot? snapshot,  String? error)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _CycleState() when $default != null:
return $default(_that.status,_that.snapshot,_that.error);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( CycleStatus status,  CycleSnapshot? snapshot,  String? error)  $default,) {final _that = this;
switch (_that) {
case _CycleState():
return $default(_that.status,_that.snapshot,_that.error);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( CycleStatus status,  CycleSnapshot? snapshot,  String? error)?  $default,) {final _that = this;
switch (_that) {
case _CycleState() when $default != null:
return $default(_that.status,_that.snapshot,_that.error);case _:
  return null;

}
}

}

/// @nodoc


class _CycleState implements CycleState {
  const _CycleState({this.status = CycleStatus.loading, this.snapshot, this.error});
  

@override@JsonKey() final  CycleStatus status;
@override final  CycleSnapshot? snapshot;
@override final  String? error;

/// Create a copy of CycleState
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$CycleStateCopyWith<_CycleState> get copyWith => __$CycleStateCopyWithImpl<_CycleState>(this, _$identity);



@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _CycleState&&(identical(other.status, status) || other.status == status)&&(identical(other.snapshot, snapshot) || other.snapshot == snapshot)&&(identical(other.error, error) || other.error == error));
}


@override
int get hashCode {
    return Object.hash(runtimeType,status,snapshot,error);
}

@override
String toString() {
    return 'CycleState(status: $status, snapshot: $snapshot, error: $error)';
}


}

/// @nodoc
abstract mixin class _$CycleStateCopyWith<$Res> implements $CycleStateCopyWith<$Res> {
  factory _$CycleStateCopyWith(_CycleState value, $Res Function(_CycleState) _then) = __$CycleStateCopyWithImpl;
@override @useResult
$Res call({
 CycleStatus status, CycleSnapshot? snapshot, String? error
});


@override $CycleSnapshotCopyWith<$Res>? get snapshot;

}
/// @nodoc
class __$CycleStateCopyWithImpl<$Res>
    implements _$CycleStateCopyWith<$Res> {
  __$CycleStateCopyWithImpl(this._self, this._then);

  final _CycleState _self;
  final $Res Function(_CycleState) _then;

/// Create a copy of CycleState
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? status = null,Object? snapshot = freezed,Object? error = freezed,}) {
  return _then(_CycleState(
status: null == status ? _self.status : status // ignore: cast_nullable_to_non_nullable
as CycleStatus,snapshot: freezed == snapshot ? _self.snapshot : snapshot // ignore: cast_nullable_to_non_nullable
as CycleSnapshot?,error: freezed == error ? _self.error : error // ignore: cast_nullable_to_non_nullable
as String?,
  ));
}

/// Create a copy of CycleState
/// with the given fields replaced by the non-null parameter values.
@override
@pragma('vm:prefer-inline')
$CycleSnapshotCopyWith<$Res>? get snapshot {
    if (_self.snapshot == null) {
    return null;
  }

  return $CycleSnapshotCopyWith<$Res>(_self.snapshot!, (value) {
    return _then(_self.copyWith(snapshot: value));
  });
}
}

// dart format on
