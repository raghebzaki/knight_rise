// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format width=80

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes

import 'package:get_it/get_it.dart' as _i174;
import 'package:injectable/injectable.dart' as _i526;
import 'package:knight_rise/core/clock/clock.dart' as _i90;
import 'package:knight_rise/core/database/app_database.dart' as _i59;
import 'package:knight_rise/core/di/injection.dart' as _i827;
import 'package:knight_rise/features/cycle/presentation/bloc/cycle_bloc.dart'
    as _i649;
import 'package:knight_rise/features/routines/data/drift_routine_repository.dart'
    as _i928;
import 'package:knight_rise/features/routines/domain/repositories/routine_repository.dart'
    as _i746;
import 'package:knight_rise/features/scheduler/data/drift_reminder_event_repository.dart'
    as _i236;
import 'package:knight_rise/features/scheduler/domain/repositories/reminder_event_repository.dart'
    as _i109;
import 'package:knight_rise/features/scheduler/domain/services/reminder_planner.dart'
    as _i493;
import 'package:knight_rise/features/scheduler/domain/usecases/cycle_usecases.dart'
    as _i768;
import 'package:knight_rise/features/settings/data/drift_settings_repository.dart'
    as _i965;
import 'package:knight_rise/features/settings/domain/repositories/settings_repository.dart'
    as _i992;
import 'package:knight_rise/features/settings/presentation/theme_cubit.dart'
    as _i131;
import 'package:knight_rise/features/work_hours/data/drift_work_schedule_repository.dart'
    as _i714;
import 'package:knight_rise/features/work_hours/domain/repositories/work_schedule_repository.dart'
    as _i559;
import 'package:timezone/timezone.dart' as _i654;

extension GetItInjectableX on _i174.GetIt {
  // initializes the registration of main-scope dependencies inside of GetIt
  Future<_i174.GetIt> init({
    String? environment,
    _i526.EnvironmentFilter? environmentFilter,
  }) async {
    final gh = _i526.GetItHelper(this, environment, environmentFilter);
    final appModule = _$AppModule();
    await gh.singletonAsync<_i654.Location>(
      () => appModule.location,
      preResolve: true,
    );
    gh.lazySingleton<_i59.AppDatabase>(
      () => appModule.database,
      dispose: _i827.closeDatabase,
    );
    gh.lazySingleton<_i90.Clock>(() => appModule.clock);
    gh.lazySingleton<_i493.ReminderPlanner>(() => appModule.planner);
    gh.lazySingleton<_i109.ReminderEventRepository>(
      () => _i236.DriftReminderEventRepository(gh<_i59.AppDatabase>()),
    );
    gh.lazySingleton<_i559.WorkScheduleRepository>(
      () => _i714.DriftWorkScheduleRepository(gh<_i59.AppDatabase>()),
    );
    gh.lazySingleton<_i746.RoutineRepository>(
      () => _i928.DriftRoutineRepository(gh<_i59.AppDatabase>()),
    );
    gh.lazySingleton<_i992.SettingsRepository>(
      () => _i965.DriftSettingsRepository(gh<_i59.AppDatabase>()),
    );
    gh.factory<_i768.BuildCycleSnapshot>(
      () => _i768.BuildCycleSnapshot(gh<_i493.ReminderPlanner>()),
    );
    gh.factory<_i768.SnoozeRoutine>(
      () => _i768.SnoozeRoutine(
        gh<_i109.ReminderEventRepository>(),
        gh<_i90.Clock>(),
        gh<_i654.Location>(),
      ),
    );
    gh.factory<_i768.WatchCycleInputs>(
      () => _i768.WatchCycleInputs(
        gh<_i746.RoutineRepository>(),
        gh<_i559.WorkScheduleRepository>(),
        gh<_i109.ReminderEventRepository>(),
        gh<_i992.SettingsRepository>(),
      ),
    );
    gh.factory<_i131.ThemeCubit>(
      () => _i131.ThemeCubit(gh<_i992.SettingsRepository>()),
    );
    gh.factory<_i768.CompleteRoutine>(
      () => _i768.CompleteRoutine(
        gh<_i109.ReminderEventRepository>(),
        gh<_i992.SettingsRepository>(),
        gh<_i90.Clock>(),
      ),
    );
    gh.factory<_i649.CycleBloc>(
      () => _i649.CycleBloc(
        gh<_i768.WatchCycleInputs>(),
        gh<_i768.BuildCycleSnapshot>(),
        gh<_i768.CompleteRoutine>(),
        gh<_i768.SnoozeRoutine>(),
        gh<_i90.Clock>(),
        gh<_i654.Location>(),
      ),
    );
    return this;
  }
}

class _$AppModule extends _i827.AppModule {}
