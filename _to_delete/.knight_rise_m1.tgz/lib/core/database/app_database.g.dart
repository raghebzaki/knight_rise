// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_database.dart';

// ignore_for_file: type=lint
class $RoutinesTable extends Routines with TableInfo<$RoutinesTable, RoutineRow> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $RoutinesTable(this.attachedDatabase, [this._alias]);
  @override
  late final GeneratedColumnWithTypeConverter<RoutineType, String> type = GeneratedColumn<String>(
    'type',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  ).withConverter<RoutineType>($RoutinesTable.$convertertype);
  static const VerificationMeta _intervalMinutesMeta = const VerificationMeta('intervalMinutes');
  @override
  late final GeneratedColumn<int> intervalMinutes = GeneratedColumn<int>(
    'interval_minutes',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _dailyTargetMeta = const VerificationMeta('dailyTarget');
  @override
  late final GeneratedColumn<int> dailyTarget = GeneratedColumn<int>(
    'daily_target',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _enabledMeta = const VerificationMeta('enabled');
  @override
  late final GeneratedColumn<bool> enabled = GeneratedColumn<bool>(
    'enabled',
    aliasedName,
    false,
    type: DriftSqlType.bool,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways('CHECK ("enabled" IN (0, 1))'),
    defaultValue: const Constant(true),
  );
  @override
  late final GeneratedColumnWithTypeConverter<ScheduleMode, String> mode = GeneratedColumn<String>(
    'mode',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  ).withConverter<ScheduleMode>($RoutinesTable.$convertermode);
  @override
  List<GeneratedColumn> get $columns => [type, intervalMinutes, dailyTarget, enabled, mode];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'routines';
  @override
  VerificationContext validateIntegrity(Insertable<RoutineRow> instance, {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('interval_minutes')) {
      context.handle(
        _intervalMinutesMeta,
        intervalMinutes.isAcceptableOrUnknown(data['interval_minutes']!, _intervalMinutesMeta),
      );
    } else if (isInserting) {
      context.missing(_intervalMinutesMeta);
    }
    if (data.containsKey('daily_target')) {
      context.handle(_dailyTargetMeta, dailyTarget.isAcceptableOrUnknown(data['daily_target']!, _dailyTargetMeta));
    } else if (isInserting) {
      context.missing(_dailyTargetMeta);
    }
    if (data.containsKey('enabled')) {
      context.handle(_enabledMeta, enabled.isAcceptableOrUnknown(data['enabled']!, _enabledMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {type};
  @override
  RoutineRow map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return RoutineRow(
      type: $RoutinesTable.$convertertype.fromSql(
        attachedDatabase.typeMapping.read(DriftSqlType.string, data['${effectivePrefix}type'])!,
      ),
      intervalMinutes: attachedDatabase.typeMapping.read(DriftSqlType.int, data['${effectivePrefix}interval_minutes'])!,
      dailyTarget: attachedDatabase.typeMapping.read(DriftSqlType.int, data['${effectivePrefix}daily_target'])!,
      enabled: attachedDatabase.typeMapping.read(DriftSqlType.bool, data['${effectivePrefix}enabled'])!,
      mode: $RoutinesTable.$convertermode.fromSql(
        attachedDatabase.typeMapping.read(DriftSqlType.string, data['${effectivePrefix}mode'])!,
      ),
    );
  }

  @override
  $RoutinesTable createAlias(String alias) {
    return $RoutinesTable(attachedDatabase, alias);
  }

  static JsonTypeConverter2<RoutineType, String, String> $convertertype = const EnumNameConverter<RoutineType>(
    RoutineType.values,
  );
  static JsonTypeConverter2<ScheduleMode, String, String> $convertermode = const EnumNameConverter<ScheduleMode>(
    ScheduleMode.values,
  );
}

class RoutineRow extends DataClass implements Insertable<RoutineRow> {
  final RoutineType type;
  final int intervalMinutes;
  final int dailyTarget;
  final bool enabled;
  final ScheduleMode mode;
  const RoutineRow({
    required this.type,
    required this.intervalMinutes,
    required this.dailyTarget,
    required this.enabled,
    required this.mode,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    {
      map['type'] = Variable<String>($RoutinesTable.$convertertype.toSql(type));
    }
    map['interval_minutes'] = Variable<int>(intervalMinutes);
    map['daily_target'] = Variable<int>(dailyTarget);
    map['enabled'] = Variable<bool>(enabled);
    {
      map['mode'] = Variable<String>($RoutinesTable.$convertermode.toSql(mode));
    }
    return map;
  }

  RoutinesCompanion toCompanion(bool nullToAbsent) {
    return RoutinesCompanion(
      type: Value(type),
      intervalMinutes: Value(intervalMinutes),
      dailyTarget: Value(dailyTarget),
      enabled: Value(enabled),
      mode: Value(mode),
    );
  }

  factory RoutineRow.fromJson(Map<String, dynamic> json, {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return RoutineRow(
      type: $RoutinesTable.$convertertype.fromJson(serializer.fromJson<String>(json['type'])),
      intervalMinutes: serializer.fromJson<int>(json['intervalMinutes']),
      dailyTarget: serializer.fromJson<int>(json['dailyTarget']),
      enabled: serializer.fromJson<bool>(json['enabled']),
      mode: $RoutinesTable.$convertermode.fromJson(serializer.fromJson<String>(json['mode'])),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'type': serializer.toJson<String>($RoutinesTable.$convertertype.toJson(type)),
      'intervalMinutes': serializer.toJson<int>(intervalMinutes),
      'dailyTarget': serializer.toJson<int>(dailyTarget),
      'enabled': serializer.toJson<bool>(enabled),
      'mode': serializer.toJson<String>($RoutinesTable.$convertermode.toJson(mode)),
    };
  }

  RoutineRow copyWith({RoutineType? type, int? intervalMinutes, int? dailyTarget, bool? enabled, ScheduleMode? mode}) =>
      RoutineRow(
        type: type ?? this.type,
        intervalMinutes: intervalMinutes ?? this.intervalMinutes,
        dailyTarget: dailyTarget ?? this.dailyTarget,
        enabled: enabled ?? this.enabled,
        mode: mode ?? this.mode,
      );
  RoutineRow copyWithCompanion(RoutinesCompanion data) {
    return RoutineRow(
      type: data.type.present ? data.type.value : this.type,
      intervalMinutes: data.intervalMinutes.present ? data.intervalMinutes.value : this.intervalMinutes,
      dailyTarget: data.dailyTarget.present ? data.dailyTarget.value : this.dailyTarget,
      enabled: data.enabled.present ? data.enabled.value : this.enabled,
      mode: data.mode.present ? data.mode.value : this.mode,
    );
  }

  @override
  String toString() {
    return (StringBuffer('RoutineRow(')
          ..write('type: $type, ')
          ..write('intervalMinutes: $intervalMinutes, ')
          ..write('dailyTarget: $dailyTarget, ')
          ..write('enabled: $enabled, ')
          ..write('mode: $mode')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(type, intervalMinutes, dailyTarget, enabled, mode);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is RoutineRow &&
          other.type == this.type &&
          other.intervalMinutes == this.intervalMinutes &&
          other.dailyTarget == this.dailyTarget &&
          other.enabled == this.enabled &&
          other.mode == this.mode);
}

class RoutinesCompanion extends UpdateCompanion<RoutineRow> {
  final Value<RoutineType> type;
  final Value<int> intervalMinutes;
  final Value<int> dailyTarget;
  final Value<bool> enabled;
  final Value<ScheduleMode> mode;
  final Value<int> rowid;
  const RoutinesCompanion({
    this.type = const Value.absent(),
    this.intervalMinutes = const Value.absent(),
    this.dailyTarget = const Value.absent(),
    this.enabled = const Value.absent(),
    this.mode = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  RoutinesCompanion.insert({
    required RoutineType type,
    required int intervalMinutes,
    required int dailyTarget,
    this.enabled = const Value.absent(),
    required ScheduleMode mode,
    this.rowid = const Value.absent(),
  }) : type = Value(type),
       intervalMinutes = Value(intervalMinutes),
       dailyTarget = Value(dailyTarget),
       mode = Value(mode);
  static Insertable<RoutineRow> custom({
    Expression<String>? type,
    Expression<int>? intervalMinutes,
    Expression<int>? dailyTarget,
    Expression<bool>? enabled,
    Expression<String>? mode,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (type != null) 'type': type,
      if (intervalMinutes != null) 'interval_minutes': intervalMinutes,
      if (dailyTarget != null) 'daily_target': dailyTarget,
      if (enabled != null) 'enabled': enabled,
      if (mode != null) 'mode': mode,
      if (rowid != null) 'rowid': rowid,
    });
  }

  RoutinesCompanion copyWith({
    Value<RoutineType>? type,
    Value<int>? intervalMinutes,
    Value<int>? dailyTarget,
    Value<bool>? enabled,
    Value<ScheduleMode>? mode,
    Value<int>? rowid,
  }) {
    return RoutinesCompanion(
      type: type ?? this.type,
      intervalMinutes: intervalMinutes ?? this.intervalMinutes,
      dailyTarget: dailyTarget ?? this.dailyTarget,
      enabled: enabled ?? this.enabled,
      mode: mode ?? this.mode,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (type.present) {
      map['type'] = Variable<String>($RoutinesTable.$convertertype.toSql(type.value));
    }
    if (intervalMinutes.present) {
      map['interval_minutes'] = Variable<int>(intervalMinutes.value);
    }
    if (dailyTarget.present) {
      map['daily_target'] = Variable<int>(dailyTarget.value);
    }
    if (enabled.present) {
      map['enabled'] = Variable<bool>(enabled.value);
    }
    if (mode.present) {
      map['mode'] = Variable<String>($RoutinesTable.$convertermode.toSql(mode.value));
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('RoutinesCompanion(')
          ..write('type: $type, ')
          ..write('intervalMinutes: $intervalMinutes, ')
          ..write('dailyTarget: $dailyTarget, ')
          ..write('enabled: $enabled, ')
          ..write('mode: $mode, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $WorkWindowsTable extends WorkWindows with TableInfo<$WorkWindowsTable, WorkWindowRow> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WorkWindowsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    hasAutoIncrement: true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'),
  );
  static const VerificationMeta _weekdayMeta = const VerificationMeta('weekday');
  @override
  late final GeneratedColumn<int> weekday = GeneratedColumn<int>(
    'weekday',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _startMinuteMeta = const VerificationMeta('startMinute');
  @override
  late final GeneratedColumn<int> startMinute = GeneratedColumn<int>(
    'start_minute',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _endMinuteMeta = const VerificationMeta('endMinute');
  @override
  late final GeneratedColumn<int> endMinute = GeneratedColumn<int>(
    'end_minute',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [id, weekday, startMinute, endMinute];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'work_windows';
  @override
  VerificationContext validateIntegrity(Insertable<WorkWindowRow> instance, {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('weekday')) {
      context.handle(_weekdayMeta, weekday.isAcceptableOrUnknown(data['weekday']!, _weekdayMeta));
    } else if (isInserting) {
      context.missing(_weekdayMeta);
    }
    if (data.containsKey('start_minute')) {
      context.handle(_startMinuteMeta, startMinute.isAcceptableOrUnknown(data['start_minute']!, _startMinuteMeta));
    } else if (isInserting) {
      context.missing(_startMinuteMeta);
    }
    if (data.containsKey('end_minute')) {
      context.handle(_endMinuteMeta, endMinute.isAcceptableOrUnknown(data['end_minute']!, _endMinuteMeta));
    } else if (isInserting) {
      context.missing(_endMinuteMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WorkWindowRow map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WorkWindowRow(
      id: attachedDatabase.typeMapping.read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      weekday: attachedDatabase.typeMapping.read(DriftSqlType.int, data['${effectivePrefix}weekday'])!,
      startMinute: attachedDatabase.typeMapping.read(DriftSqlType.int, data['${effectivePrefix}start_minute'])!,
      endMinute: attachedDatabase.typeMapping.read(DriftSqlType.int, data['${effectivePrefix}end_minute'])!,
    );
  }

  @override
  $WorkWindowsTable createAlias(String alias) {
    return $WorkWindowsTable(attachedDatabase, alias);
  }
}

class WorkWindowRow extends DataClass implements Insertable<WorkWindowRow> {
  final int id;

  /// ISO weekday, 1 = Monday … 7 = Sunday.
  final int weekday;
  final int startMinute;
  final int endMinute;
  const WorkWindowRow({required this.id, required this.weekday, required this.startMinute, required this.endMinute});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['weekday'] = Variable<int>(weekday);
    map['start_minute'] = Variable<int>(startMinute);
    map['end_minute'] = Variable<int>(endMinute);
    return map;
  }

  WorkWindowsCompanion toCompanion(bool nullToAbsent) {
    return WorkWindowsCompanion(
      id: Value(id),
      weekday: Value(weekday),
      startMinute: Value(startMinute),
      endMinute: Value(endMinute),
    );
  }

  factory WorkWindowRow.fromJson(Map<String, dynamic> json, {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WorkWindowRow(
      id: serializer.fromJson<int>(json['id']),
      weekday: serializer.fromJson<int>(json['weekday']),
      startMinute: serializer.fromJson<int>(json['startMinute']),
      endMinute: serializer.fromJson<int>(json['endMinute']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'weekday': serializer.toJson<int>(weekday),
      'startMinute': serializer.toJson<int>(startMinute),
      'endMinute': serializer.toJson<int>(endMinute),
    };
  }

  WorkWindowRow copyWith({int? id, int? weekday, int? startMinute, int? endMinute}) => WorkWindowRow(
    id: id ?? this.id,
    weekday: weekday ?? this.weekday,
    startMinute: startMinute ?? this.startMinute,
    endMinute: endMinute ?? this.endMinute,
  );
  WorkWindowRow copyWithCompanion(WorkWindowsCompanion data) {
    return WorkWindowRow(
      id: data.id.present ? data.id.value : this.id,
      weekday: data.weekday.present ? data.weekday.value : this.weekday,
      startMinute: data.startMinute.present ? data.startMinute.value : this.startMinute,
      endMinute: data.endMinute.present ? data.endMinute.value : this.endMinute,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WorkWindowRow(')
          ..write('id: $id, ')
          ..write('weekday: $weekday, ')
          ..write('startMinute: $startMinute, ')
          ..write('endMinute: $endMinute')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, weekday, startMinute, endMinute);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WorkWindowRow &&
          other.id == this.id &&
          other.weekday == this.weekday &&
          other.startMinute == this.startMinute &&
          other.endMinute == this.endMinute);
}

class WorkWindowsCompanion extends UpdateCompanion<WorkWindowRow> {
  final Value<int> id;
  final Value<int> weekday;
  final Value<int> startMinute;
  final Value<int> endMinute;
  const WorkWindowsCompanion({
    this.id = const Value.absent(),
    this.weekday = const Value.absent(),
    this.startMinute = const Value.absent(),
    this.endMinute = const Value.absent(),
  });
  WorkWindowsCompanion.insert({
    this.id = const Value.absent(),
    required int weekday,
    required int startMinute,
    required int endMinute,
  }) : weekday = Value(weekday),
       startMinute = Value(startMinute),
       endMinute = Value(endMinute);
  static Insertable<WorkWindowRow> custom({
    Expression<int>? id,
    Expression<int>? weekday,
    Expression<int>? startMinute,
    Expression<int>? endMinute,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (weekday != null) 'weekday': weekday,
      if (startMinute != null) 'start_minute': startMinute,
      if (endMinute != null) 'end_minute': endMinute,
    });
  }

  WorkWindowsCompanion copyWith({Value<int>? id, Value<int>? weekday, Value<int>? startMinute, Value<int>? endMinute}) {
    return WorkWindowsCompanion(
      id: id ?? this.id,
      weekday: weekday ?? this.weekday,
      startMinute: startMinute ?? this.startMinute,
      endMinute: endMinute ?? this.endMinute,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (weekday.present) {
      map['weekday'] = Variable<int>(weekday.value);
    }
    if (startMinute.present) {
      map['start_minute'] = Variable<int>(startMinute.value);
    }
    if (endMinute.present) {
      map['end_minute'] = Variable<int>(endMinute.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WorkWindowsCompanion(')
          ..write('id: $id, ')
          ..write('weekday: $weekday, ')
          ..write('startMinute: $startMinute, ')
          ..write('endMinute: $endMinute')
          ..write(')'))
        .toString();
  }
}

class $ReminderEventsTable extends ReminderEvents with TableInfo<$ReminderEventsTable, ReminderEventRow> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ReminderEventsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    hasAutoIncrement: true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'),
  );
  @override
  late final GeneratedColumnWithTypeConverter<RoutineType, String> routineType = GeneratedColumn<String>(
    'routine_type',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  ).withConverter<RoutineType>($ReminderEventsTable.$converterroutineType);
  static const VerificationMeta _outcomeMeta = const VerificationMeta('outcome');
  @override
  late final GeneratedColumn<String> outcome = GeneratedColumn<String>(
    'outcome',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _atMeta = const VerificationMeta('at');
  @override
  late final GeneratedColumn<DateTime> at = GeneratedColumn<DateTime>(
    'at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _scheduledAtMeta = const VerificationMeta('scheduledAt');
  @override
  late final GeneratedColumn<DateTime> scheduledAt = GeneratedColumn<DateTime>(
    'scheduled_at',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _snoozedUntilMeta = const VerificationMeta('snoozedUntil');
  @override
  late final GeneratedColumn<DateTime> snoozedUntil = GeneratedColumn<DateTime>(
    'snoozed_until',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _waterMlMeta = const VerificationMeta('waterMl');
  @override
  late final GeneratedColumn<int> waterMl = GeneratedColumn<int>(
    'water_ml',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, routineType, outcome, at, scheduledAt, snoozedUntil, waterMl];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'reminder_events';
  @override
  VerificationContext validateIntegrity(Insertable<ReminderEventRow> instance, {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('outcome')) {
      context.handle(_outcomeMeta, outcome.isAcceptableOrUnknown(data['outcome']!, _outcomeMeta));
    } else if (isInserting) {
      context.missing(_outcomeMeta);
    }
    if (data.containsKey('at')) {
      context.handle(_atMeta, at.isAcceptableOrUnknown(data['at']!, _atMeta));
    } else if (isInserting) {
      context.missing(_atMeta);
    }
    if (data.containsKey('scheduled_at')) {
      context.handle(_scheduledAtMeta, scheduledAt.isAcceptableOrUnknown(data['scheduled_at']!, _scheduledAtMeta));
    }
    if (data.containsKey('snoozed_until')) {
      context.handle(_snoozedUntilMeta, snoozedUntil.isAcceptableOrUnknown(data['snoozed_until']!, _snoozedUntilMeta));
    }
    if (data.containsKey('water_ml')) {
      context.handle(_waterMlMeta, waterMl.isAcceptableOrUnknown(data['water_ml']!, _waterMlMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ReminderEventRow map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ReminderEventRow(
      id: attachedDatabase.typeMapping.read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      routineType: $ReminderEventsTable.$converterroutineType.fromSql(
        attachedDatabase.typeMapping.read(DriftSqlType.string, data['${effectivePrefix}routine_type'])!,
      ),
      outcome: attachedDatabase.typeMapping.read(DriftSqlType.string, data['${effectivePrefix}outcome'])!,
      at: attachedDatabase.typeMapping.read(DriftSqlType.dateTime, data['${effectivePrefix}at'])!,
      scheduledAt: attachedDatabase.typeMapping.read(DriftSqlType.dateTime, data['${effectivePrefix}scheduled_at']),
      snoozedUntil: attachedDatabase.typeMapping.read(DriftSqlType.dateTime, data['${effectivePrefix}snoozed_until']),
      waterMl: attachedDatabase.typeMapping.read(DriftSqlType.int, data['${effectivePrefix}water_ml']),
    );
  }

  @override
  $ReminderEventsTable createAlias(String alias) {
    return $ReminderEventsTable(attachedDatabase, alias);
  }

  static JsonTypeConverter2<RoutineType, String, String> $converterroutineType = const EnumNameConverter<RoutineType>(
    RoutineType.values,
  );
}

class ReminderEventRow extends DataClass implements Insertable<ReminderEventRow> {
  final int id;
  final RoutineType routineType;
  final String outcome;
  final DateTime at;
  final DateTime? scheduledAt;
  final DateTime? snoozedUntil;
  final int? waterMl;
  const ReminderEventRow({
    required this.id,
    required this.routineType,
    required this.outcome,
    required this.at,
    this.scheduledAt,
    this.snoozedUntil,
    this.waterMl,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    {
      map['routine_type'] = Variable<String>($ReminderEventsTable.$converterroutineType.toSql(routineType));
    }
    map['outcome'] = Variable<String>(outcome);
    map['at'] = Variable<DateTime>(at);
    if (!nullToAbsent || scheduledAt != null) {
      map['scheduled_at'] = Variable<DateTime>(scheduledAt);
    }
    if (!nullToAbsent || snoozedUntil != null) {
      map['snoozed_until'] = Variable<DateTime>(snoozedUntil);
    }
    if (!nullToAbsent || waterMl != null) {
      map['water_ml'] = Variable<int>(waterMl);
    }
    return map;
  }

  ReminderEventsCompanion toCompanion(bool nullToAbsent) {
    return ReminderEventsCompanion(
      id: Value(id),
      routineType: Value(routineType),
      outcome: Value(outcome),
      at: Value(at),
      scheduledAt: scheduledAt == null && nullToAbsent ? const Value.absent() : Value(scheduledAt),
      snoozedUntil: snoozedUntil == null && nullToAbsent ? const Value.absent() : Value(snoozedUntil),
      waterMl: waterMl == null && nullToAbsent ? const Value.absent() : Value(waterMl),
    );
  }

  factory ReminderEventRow.fromJson(Map<String, dynamic> json, {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ReminderEventRow(
      id: serializer.fromJson<int>(json['id']),
      routineType: $ReminderEventsTable.$converterroutineType.fromJson(
        serializer.fromJson<String>(json['routineType']),
      ),
      outcome: serializer.fromJson<String>(json['outcome']),
      at: serializer.fromJson<DateTime>(json['at']),
      scheduledAt: serializer.fromJson<DateTime?>(json['scheduledAt']),
      snoozedUntil: serializer.fromJson<DateTime?>(json['snoozedUntil']),
      waterMl: serializer.fromJson<int?>(json['waterMl']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'routineType': serializer.toJson<String>($ReminderEventsTable.$converterroutineType.toJson(routineType)),
      'outcome': serializer.toJson<String>(outcome),
      'at': serializer.toJson<DateTime>(at),
      'scheduledAt': serializer.toJson<DateTime?>(scheduledAt),
      'snoozedUntil': serializer.toJson<DateTime?>(snoozedUntil),
      'waterMl': serializer.toJson<int?>(waterMl),
    };
  }

  ReminderEventRow copyWith({
    int? id,
    RoutineType? routineType,
    String? outcome,
    DateTime? at,
    Value<DateTime?> scheduledAt = const Value.absent(),
    Value<DateTime?> snoozedUntil = const Value.absent(),
    Value<int?> waterMl = const Value.absent(),
  }) => ReminderEventRow(
    id: id ?? this.id,
    routineType: routineType ?? this.routineType,
    outcome: outcome ?? this.outcome,
    at: at ?? this.at,
    scheduledAt: scheduledAt.present ? scheduledAt.value : this.scheduledAt,
    snoozedUntil: snoozedUntil.present ? snoozedUntil.value : this.snoozedUntil,
    waterMl: waterMl.present ? waterMl.value : this.waterMl,
  );
  ReminderEventRow copyWithCompanion(ReminderEventsCompanion data) {
    return ReminderEventRow(
      id: data.id.present ? data.id.value : this.id,
      routineType: data.routineType.present ? data.routineType.value : this.routineType,
      outcome: data.outcome.present ? data.outcome.value : this.outcome,
      at: data.at.present ? data.at.value : this.at,
      scheduledAt: data.scheduledAt.present ? data.scheduledAt.value : this.scheduledAt,
      snoozedUntil: data.snoozedUntil.present ? data.snoozedUntil.value : this.snoozedUntil,
      waterMl: data.waterMl.present ? data.waterMl.value : this.waterMl,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ReminderEventRow(')
          ..write('id: $id, ')
          ..write('routineType: $routineType, ')
          ..write('outcome: $outcome, ')
          ..write('at: $at, ')
          ..write('scheduledAt: $scheduledAt, ')
          ..write('snoozedUntil: $snoozedUntil, ')
          ..write('waterMl: $waterMl')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, routineType, outcome, at, scheduledAt, snoozedUntil, waterMl);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ReminderEventRow &&
          other.id == this.id &&
          other.routineType == this.routineType &&
          other.outcome == this.outcome &&
          other.at == this.at &&
          other.scheduledAt == this.scheduledAt &&
          other.snoozedUntil == this.snoozedUntil &&
          other.waterMl == this.waterMl);
}

class ReminderEventsCompanion extends UpdateCompanion<ReminderEventRow> {
  final Value<int> id;
  final Value<RoutineType> routineType;
  final Value<String> outcome;
  final Value<DateTime> at;
  final Value<DateTime?> scheduledAt;
  final Value<DateTime?> snoozedUntil;
  final Value<int?> waterMl;
  const ReminderEventsCompanion({
    this.id = const Value.absent(),
    this.routineType = const Value.absent(),
    this.outcome = const Value.absent(),
    this.at = const Value.absent(),
    this.scheduledAt = const Value.absent(),
    this.snoozedUntil = const Value.absent(),
    this.waterMl = const Value.absent(),
  });
  ReminderEventsCompanion.insert({
    this.id = const Value.absent(),
    required RoutineType routineType,
    required String outcome,
    required DateTime at,
    this.scheduledAt = const Value.absent(),
    this.snoozedUntil = const Value.absent(),
    this.waterMl = const Value.absent(),
  }) : routineType = Value(routineType),
       outcome = Value(outcome),
       at = Value(at);
  static Insertable<ReminderEventRow> custom({
    Expression<int>? id,
    Expression<String>? routineType,
    Expression<String>? outcome,
    Expression<DateTime>? at,
    Expression<DateTime>? scheduledAt,
    Expression<DateTime>? snoozedUntil,
    Expression<int>? waterMl,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (routineType != null) 'routine_type': routineType,
      if (outcome != null) 'outcome': outcome,
      if (at != null) 'at': at,
      if (scheduledAt != null) 'scheduled_at': scheduledAt,
      if (snoozedUntil != null) 'snoozed_until': snoozedUntil,
      if (waterMl != null) 'water_ml': waterMl,
    });
  }

  ReminderEventsCompanion copyWith({
    Value<int>? id,
    Value<RoutineType>? routineType,
    Value<String>? outcome,
    Value<DateTime>? at,
    Value<DateTime?>? scheduledAt,
    Value<DateTime?>? snoozedUntil,
    Value<int?>? waterMl,
  }) {
    return ReminderEventsCompanion(
      id: id ?? this.id,
      routineType: routineType ?? this.routineType,
      outcome: outcome ?? this.outcome,
      at: at ?? this.at,
      scheduledAt: scheduledAt ?? this.scheduledAt,
      snoozedUntil: snoozedUntil ?? this.snoozedUntil,
      waterMl: waterMl ?? this.waterMl,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (routineType.present) {
      map['routine_type'] = Variable<String>($ReminderEventsTable.$converterroutineType.toSql(routineType.value));
    }
    if (outcome.present) {
      map['outcome'] = Variable<String>(outcome.value);
    }
    if (at.present) {
      map['at'] = Variable<DateTime>(at.value);
    }
    if (scheduledAt.present) {
      map['scheduled_at'] = Variable<DateTime>(scheduledAt.value);
    }
    if (snoozedUntil.present) {
      map['snoozed_until'] = Variable<DateTime>(snoozedUntil.value);
    }
    if (waterMl.present) {
      map['water_ml'] = Variable<int>(waterMl.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ReminderEventsCompanion(')
          ..write('id: $id, ')
          ..write('routineType: $routineType, ')
          ..write('outcome: $outcome, ')
          ..write('at: $at, ')
          ..write('scheduledAt: $scheduledAt, ')
          ..write('snoozedUntil: $snoozedUntil, ')
          ..write('waterMl: $waterMl')
          ..write(')'))
        .toString();
  }
}

class $AppSettingsTableTable extends AppSettingsTable with TableInfo<$AppSettingsTableTable, SettingsRow> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AppSettingsTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(1),
  );
  static const VerificationMeta _themeVariantMeta = const VerificationMeta('themeVariant');
  @override
  late final GeneratedColumn<String> themeVariant = GeneratedColumn<String>(
    'theme_variant',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
    defaultValue: const Constant('midnight'),
  );
  static const VerificationMeta _precisionTimingMeta = const VerificationMeta('precisionTiming');
  @override
  late final GeneratedColumn<bool> precisionTiming = GeneratedColumn<bool>(
    'precision_timing',
    aliasedName,
    false,
    type: DriftSqlType.bool,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways('CHECK ("precision_timing" IN (0, 1))'),
    defaultValue: const Constant(false),
  );
  static const VerificationMeta _waterPerTapMlMeta = const VerificationMeta('waterPerTapMl');
  @override
  late final GeneratedColumn<int> waterPerTapMl = GeneratedColumn<int>(
    'water_per_tap_ml',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(250),
  );
  @override
  List<GeneratedColumn> get $columns => [id, themeVariant, precisionTiming, waterPerTapMl];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'app_settings';
  @override
  VerificationContext validateIntegrity(Insertable<SettingsRow> instance, {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('theme_variant')) {
      context.handle(_themeVariantMeta, themeVariant.isAcceptableOrUnknown(data['theme_variant']!, _themeVariantMeta));
    }
    if (data.containsKey('precision_timing')) {
      context.handle(
        _precisionTimingMeta,
        precisionTiming.isAcceptableOrUnknown(data['precision_timing']!, _precisionTimingMeta),
      );
    }
    if (data.containsKey('water_per_tap_ml')) {
      context.handle(
        _waterPerTapMlMeta,
        waterPerTapMl.isAcceptableOrUnknown(data['water_per_tap_ml']!, _waterPerTapMlMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SettingsRow map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SettingsRow(
      id: attachedDatabase.typeMapping.read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      themeVariant: attachedDatabase.typeMapping.read(DriftSqlType.string, data['${effectivePrefix}theme_variant'])!,
      precisionTiming: attachedDatabase.typeMapping.read(
        DriftSqlType.bool,
        data['${effectivePrefix}precision_timing'],
      )!,
      waterPerTapMl: attachedDatabase.typeMapping.read(DriftSqlType.int, data['${effectivePrefix}water_per_tap_ml'])!,
    );
  }

  @override
  $AppSettingsTableTable createAlias(String alias) {
    return $AppSettingsTableTable(attachedDatabase, alias);
  }
}

class SettingsRow extends DataClass implements Insertable<SettingsRow> {
  final int id;
  final String themeVariant;
  final bool precisionTiming;
  final int waterPerTapMl;
  const SettingsRow({
    required this.id,
    required this.themeVariant,
    required this.precisionTiming,
    required this.waterPerTapMl,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['theme_variant'] = Variable<String>(themeVariant);
    map['precision_timing'] = Variable<bool>(precisionTiming);
    map['water_per_tap_ml'] = Variable<int>(waterPerTapMl);
    return map;
  }

  AppSettingsTableCompanion toCompanion(bool nullToAbsent) {
    return AppSettingsTableCompanion(
      id: Value(id),
      themeVariant: Value(themeVariant),
      precisionTiming: Value(precisionTiming),
      waterPerTapMl: Value(waterPerTapMl),
    );
  }

  factory SettingsRow.fromJson(Map<String, dynamic> json, {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SettingsRow(
      id: serializer.fromJson<int>(json['id']),
      themeVariant: serializer.fromJson<String>(json['themeVariant']),
      precisionTiming: serializer.fromJson<bool>(json['precisionTiming']),
      waterPerTapMl: serializer.fromJson<int>(json['waterPerTapMl']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'themeVariant': serializer.toJson<String>(themeVariant),
      'precisionTiming': serializer.toJson<bool>(precisionTiming),
      'waterPerTapMl': serializer.toJson<int>(waterPerTapMl),
    };
  }

  SettingsRow copyWith({int? id, String? themeVariant, bool? precisionTiming, int? waterPerTapMl}) => SettingsRow(
    id: id ?? this.id,
    themeVariant: themeVariant ?? this.themeVariant,
    precisionTiming: precisionTiming ?? this.precisionTiming,
    waterPerTapMl: waterPerTapMl ?? this.waterPerTapMl,
  );
  SettingsRow copyWithCompanion(AppSettingsTableCompanion data) {
    return SettingsRow(
      id: data.id.present ? data.id.value : this.id,
      themeVariant: data.themeVariant.present ? data.themeVariant.value : this.themeVariant,
      precisionTiming: data.precisionTiming.present ? data.precisionTiming.value : this.precisionTiming,
      waterPerTapMl: data.waterPerTapMl.present ? data.waterPerTapMl.value : this.waterPerTapMl,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SettingsRow(')
          ..write('id: $id, ')
          ..write('themeVariant: $themeVariant, ')
          ..write('precisionTiming: $precisionTiming, ')
          ..write('waterPerTapMl: $waterPerTapMl')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, themeVariant, precisionTiming, waterPerTapMl);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SettingsRow &&
          other.id == this.id &&
          other.themeVariant == this.themeVariant &&
          other.precisionTiming == this.precisionTiming &&
          other.waterPerTapMl == this.waterPerTapMl);
}

class AppSettingsTableCompanion extends UpdateCompanion<SettingsRow> {
  final Value<int> id;
  final Value<String> themeVariant;
  final Value<bool> precisionTiming;
  final Value<int> waterPerTapMl;
  const AppSettingsTableCompanion({
    this.id = const Value.absent(),
    this.themeVariant = const Value.absent(),
    this.precisionTiming = const Value.absent(),
    this.waterPerTapMl = const Value.absent(),
  });
  AppSettingsTableCompanion.insert({
    this.id = const Value.absent(),
    this.themeVariant = const Value.absent(),
    this.precisionTiming = const Value.absent(),
    this.waterPerTapMl = const Value.absent(),
  });
  static Insertable<SettingsRow> custom({
    Expression<int>? id,
    Expression<String>? themeVariant,
    Expression<bool>? precisionTiming,
    Expression<int>? waterPerTapMl,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (themeVariant != null) 'theme_variant': themeVariant,
      if (precisionTiming != null) 'precision_timing': precisionTiming,
      if (waterPerTapMl != null) 'water_per_tap_ml': waterPerTapMl,
    });
  }

  AppSettingsTableCompanion copyWith({
    Value<int>? id,
    Value<String>? themeVariant,
    Value<bool>? precisionTiming,
    Value<int>? waterPerTapMl,
  }) {
    return AppSettingsTableCompanion(
      id: id ?? this.id,
      themeVariant: themeVariant ?? this.themeVariant,
      precisionTiming: precisionTiming ?? this.precisionTiming,
      waterPerTapMl: waterPerTapMl ?? this.waterPerTapMl,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (themeVariant.present) {
      map['theme_variant'] = Variable<String>(themeVariant.value);
    }
    if (precisionTiming.present) {
      map['precision_timing'] = Variable<bool>(precisionTiming.value);
    }
    if (waterPerTapMl.present) {
      map['water_per_tap_ml'] = Variable<int>(waterPerTapMl.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AppSettingsTableCompanion(')
          ..write('id: $id, ')
          ..write('themeVariant: $themeVariant, ')
          ..write('precisionTiming: $precisionTiming, ')
          ..write('waterPerTapMl: $waterPerTapMl')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $RoutinesTable routines = $RoutinesTable(this);
  late final $WorkWindowsTable workWindows = $WorkWindowsTable(this);
  late final $ReminderEventsTable reminderEvents = $ReminderEventsTable(this);
  late final $AppSettingsTableTable appSettingsTable = $AppSettingsTableTable(this);
  late final Index idxEventsAt = Index('idx_events_at', 'CREATE INDEX idx_events_at ON reminder_events (at)');
  late final Index idxEventsTypeAt = Index(
    'idx_events_type_at',
    'CREATE INDEX idx_events_type_at ON reminder_events (routine_type, at)',
  );
  @override
  Iterable<TableInfo<Table, Object?>> get allTables => allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
    routines,
    workWindows,
    reminderEvents,
    appSettingsTable,
    idxEventsAt,
    idxEventsTypeAt,
  ];
}

typedef $$RoutinesTableCreateCompanionBuilder = RoutinesCompanion Function({
  required RoutineType type,
  required int intervalMinutes,
  required int dailyTarget,
  Value<bool> enabled,
  required ScheduleMode mode,
  Value<int> rowid,
});
typedef $$RoutinesTableUpdateCompanionBuilder = RoutinesCompanion Function({
  Value<RoutineType> type,
  Value<int> intervalMinutes,
  Value<int> dailyTarget,
  Value<bool> enabled,
  Value<ScheduleMode> mode,
  Value<int> rowid,
});

class $$RoutinesTableFilterComposer extends Composer<_$AppDatabase, $RoutinesTable> {
  $$RoutinesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnWithTypeConverterFilters<RoutineType, RoutineType, String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => ColumnWithTypeConverterFilters(column));

  ColumnFilters<int> get intervalMinutes =>
      $composableBuilder(column: $table.intervalMinutes, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get dailyTarget =>
      $composableBuilder(column: $table.dailyTarget, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get enabled =>
      $composableBuilder(column: $table.enabled, builder: (column) => ColumnFilters(column));

  ColumnWithTypeConverterFilters<ScheduleMode, ScheduleMode, String> get mode =>
      $composableBuilder(column: $table.mode, builder: (column) => ColumnWithTypeConverterFilters(column));
}

class $$RoutinesTableOrderingComposer extends Composer<_$AppDatabase, $RoutinesTable> {
  $$RoutinesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get intervalMinutes =>
      $composableBuilder(column: $table.intervalMinutes, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get dailyTarget =>
      $composableBuilder(column: $table.dailyTarget, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get enabled =>
      $composableBuilder(column: $table.enabled, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get mode =>
      $composableBuilder(column: $table.mode, builder: (column) => ColumnOrderings(column));
}

class $$RoutinesTableAnnotationComposer extends Composer<_$AppDatabase, $RoutinesTable> {
  $$RoutinesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumnWithTypeConverter<RoutineType, String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);

  GeneratedColumn<int> get intervalMinutes =>
      $composableBuilder(column: $table.intervalMinutes, builder: (column) => column);

  GeneratedColumn<int> get dailyTarget => $composableBuilder(column: $table.dailyTarget, builder: (column) => column);

  GeneratedColumn<bool> get enabled => $composableBuilder(column: $table.enabled, builder: (column) => column);

  GeneratedColumnWithTypeConverter<ScheduleMode, String> get mode =>
      $composableBuilder(column: $table.mode, builder: (column) => column);
}

class $$RoutinesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $RoutinesTable,
          RoutineRow,
          $$RoutinesTableFilterComposer,
          $$RoutinesTableOrderingComposer,
          $$RoutinesTableAnnotationComposer,
          $$RoutinesTableCreateCompanionBuilder,
          $$RoutinesTableUpdateCompanionBuilder,
          (RoutineRow, BaseReferences<_$AppDatabase, $RoutinesTable, RoutineRow>),
          RoutineRow,
          PrefetchHooks Function()
        > {
  $$RoutinesTableTableManager(_$AppDatabase db, $RoutinesTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () => $$RoutinesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () => $$RoutinesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () => $$RoutinesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<RoutineType> type = const Value.absent(),
                Value<int> intervalMinutes = const Value.absent(),
                Value<int> dailyTarget = const Value.absent(),
                Value<bool> enabled = const Value.absent(),
                Value<ScheduleMode> mode = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => RoutinesCompanion(
                type: type,
                intervalMinutes: intervalMinutes,
                dailyTarget: dailyTarget,
                enabled: enabled,
                mode: mode,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required RoutineType type,
                required int intervalMinutes,
                required int dailyTarget,
                Value<bool> enabled = const Value.absent(),
                required ScheduleMode mode,
                Value<int> rowid = const Value.absent(),
              }) => RoutinesCompanion.insert(
                type: type,
                intervalMinutes: intervalMinutes,
                dailyTarget: dailyTarget,
                enabled: enabled,
                mode: mode,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map(
                (e) => (
                  e.readTable<$RoutinesTable, RoutineRow>(table),
                  BaseReferences<_$AppDatabase, $RoutinesTable, RoutineRow>(db, table, e),
                ),
              )
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$RoutinesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $RoutinesTable,
      RoutineRow,
      $$RoutinesTableFilterComposer,
      $$RoutinesTableOrderingComposer,
      $$RoutinesTableAnnotationComposer,
      $$RoutinesTableCreateCompanionBuilder,
      $$RoutinesTableUpdateCompanionBuilder,
      (RoutineRow, BaseReferences<_$AppDatabase, $RoutinesTable, RoutineRow>),
      RoutineRow,
      PrefetchHooks Function()
    >;
typedef $$WorkWindowsTableCreateCompanionBuilder = WorkWindowsCompanion Function({
  Value<int> id,
  required int weekday,
  required int startMinute,
  required int endMinute,
});
typedef $$WorkWindowsTableUpdateCompanionBuilder = WorkWindowsCompanion Function({
  Value<int> id,
  Value<int> weekday,
  Value<int> startMinute,
  Value<int> endMinute,
});

class $$WorkWindowsTableFilterComposer extends Composer<_$AppDatabase, $WorkWindowsTable> {
  $$WorkWindowsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get weekday =>
      $composableBuilder(column: $table.weekday, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get startMinute =>
      $composableBuilder(column: $table.startMinute, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get endMinute =>
      $composableBuilder(column: $table.endMinute, builder: (column) => ColumnFilters(column));
}

class $$WorkWindowsTableOrderingComposer extends Composer<_$AppDatabase, $WorkWindowsTable> {
  $$WorkWindowsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get weekday =>
      $composableBuilder(column: $table.weekday, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get startMinute =>
      $composableBuilder(column: $table.startMinute, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get endMinute =>
      $composableBuilder(column: $table.endMinute, builder: (column) => ColumnOrderings(column));
}

class $$WorkWindowsTableAnnotationComposer extends Composer<_$AppDatabase, $WorkWindowsTable> {
  $$WorkWindowsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id => $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get weekday => $composableBuilder(column: $table.weekday, builder: (column) => column);

  GeneratedColumn<int> get startMinute => $composableBuilder(column: $table.startMinute, builder: (column) => column);

  GeneratedColumn<int> get endMinute => $composableBuilder(column: $table.endMinute, builder: (column) => column);
}

class $$WorkWindowsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $WorkWindowsTable,
          WorkWindowRow,
          $$WorkWindowsTableFilterComposer,
          $$WorkWindowsTableOrderingComposer,
          $$WorkWindowsTableAnnotationComposer,
          $$WorkWindowsTableCreateCompanionBuilder,
          $$WorkWindowsTableUpdateCompanionBuilder,
          (WorkWindowRow, BaseReferences<_$AppDatabase, $WorkWindowsTable, WorkWindowRow>),
          WorkWindowRow,
          PrefetchHooks Function()
        > {
  $$WorkWindowsTableTableManager(_$AppDatabase db, $WorkWindowsTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () => $$WorkWindowsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () => $$WorkWindowsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () => $$WorkWindowsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<int> weekday = const Value.absent(),
            Value<int> startMinute = const Value.absent(),
            Value<int> endMinute = const Value.absent(),
          }) => WorkWindowsCompanion(id: id, weekday: weekday, startMinute: startMinute, endMinute: endMinute),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required int weekday,
            required int startMinute,
            required int endMinute,
          }) => WorkWindowsCompanion.insert(id: id, weekday: weekday, startMinute: startMinute, endMinute: endMinute),
          withReferenceMapper: (p0) => p0
              .map(
                (e) => (
                  e.readTable<$WorkWindowsTable, WorkWindowRow>(table),
                  BaseReferences<_$AppDatabase, $WorkWindowsTable, WorkWindowRow>(db, table, e),
                ),
              )
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$WorkWindowsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $WorkWindowsTable,
      WorkWindowRow,
      $$WorkWindowsTableFilterComposer,
      $$WorkWindowsTableOrderingComposer,
      $$WorkWindowsTableAnnotationComposer,
      $$WorkWindowsTableCreateCompanionBuilder,
      $$WorkWindowsTableUpdateCompanionBuilder,
      (WorkWindowRow, BaseReferences<_$AppDatabase, $WorkWindowsTable, WorkWindowRow>),
      WorkWindowRow,
      PrefetchHooks Function()
    >;
typedef $$ReminderEventsTableCreateCompanionBuilder = ReminderEventsCompanion Function({
  Value<int> id,
  required RoutineType routineType,
  required String outcome,
  required DateTime at,
  Value<DateTime?> scheduledAt,
  Value<DateTime?> snoozedUntil,
  Value<int?> waterMl,
});
typedef $$ReminderEventsTableUpdateCompanionBuilder = ReminderEventsCompanion Function({
  Value<int> id,
  Value<RoutineType> routineType,
  Value<String> outcome,
  Value<DateTime> at,
  Value<DateTime?> scheduledAt,
  Value<DateTime?> snoozedUntil,
  Value<int?> waterMl,
});

class $$ReminderEventsTableFilterComposer extends Composer<_$AppDatabase, $ReminderEventsTable> {
  $$ReminderEventsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnWithTypeConverterFilters<RoutineType, RoutineType, String> get routineType =>
      $composableBuilder(column: $table.routineType, builder: (column) => ColumnWithTypeConverterFilters(column));

  ColumnFilters<String> get outcome =>
      $composableBuilder(column: $table.outcome, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get at => $composableBuilder(column: $table.at, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get scheduledAt =>
      $composableBuilder(column: $table.scheduledAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get snoozedUntil =>
      $composableBuilder(column: $table.snoozedUntil, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get waterMl =>
      $composableBuilder(column: $table.waterMl, builder: (column) => ColumnFilters(column));
}

class $$ReminderEventsTableOrderingComposer extends Composer<_$AppDatabase, $ReminderEventsTable> {
  $$ReminderEventsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get routineType =>
      $composableBuilder(column: $table.routineType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get outcome =>
      $composableBuilder(column: $table.outcome, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get at =>
      $composableBuilder(column: $table.at, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get scheduledAt =>
      $composableBuilder(column: $table.scheduledAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get snoozedUntil =>
      $composableBuilder(column: $table.snoozedUntil, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get waterMl =>
      $composableBuilder(column: $table.waterMl, builder: (column) => ColumnOrderings(column));
}

class $$ReminderEventsTableAnnotationComposer extends Composer<_$AppDatabase, $ReminderEventsTable> {
  $$ReminderEventsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id => $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumnWithTypeConverter<RoutineType, String> get routineType =>
      $composableBuilder(column: $table.routineType, builder: (column) => column);

  GeneratedColumn<String> get outcome => $composableBuilder(column: $table.outcome, builder: (column) => column);

  GeneratedColumn<DateTime> get at => $composableBuilder(column: $table.at, builder: (column) => column);

  GeneratedColumn<DateTime> get scheduledAt =>
      $composableBuilder(column: $table.scheduledAt, builder: (column) => column);

  GeneratedColumn<DateTime> get snoozedUntil =>
      $composableBuilder(column: $table.snoozedUntil, builder: (column) => column);

  GeneratedColumn<int> get waterMl => $composableBuilder(column: $table.waterMl, builder: (column) => column);
}

class $$ReminderEventsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ReminderEventsTable,
          ReminderEventRow,
          $$ReminderEventsTableFilterComposer,
          $$ReminderEventsTableOrderingComposer,
          $$ReminderEventsTableAnnotationComposer,
          $$ReminderEventsTableCreateCompanionBuilder,
          $$ReminderEventsTableUpdateCompanionBuilder,
          (ReminderEventRow, BaseReferences<_$AppDatabase, $ReminderEventsTable, ReminderEventRow>),
          ReminderEventRow,
          PrefetchHooks Function()
        > {
  $$ReminderEventsTableTableManager(_$AppDatabase db, $ReminderEventsTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () => $$ReminderEventsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () => $$ReminderEventsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () => $$ReminderEventsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<RoutineType> routineType = const Value.absent(),
                Value<String> outcome = const Value.absent(),
                Value<DateTime> at = const Value.absent(),
                Value<DateTime?> scheduledAt = const Value.absent(),
                Value<DateTime?> snoozedUntil = const Value.absent(),
                Value<int?> waterMl = const Value.absent(),
              }) => ReminderEventsCompanion(
                id: id,
                routineType: routineType,
                outcome: outcome,
                at: at,
                scheduledAt: scheduledAt,
                snoozedUntil: snoozedUntil,
                waterMl: waterMl,
              ),
          createCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                required RoutineType routineType,
                required String outcome,
                required DateTime at,
                Value<DateTime?> scheduledAt = const Value.absent(),
                Value<DateTime?> snoozedUntil = const Value.absent(),
                Value<int?> waterMl = const Value.absent(),
              }) => ReminderEventsCompanion.insert(
                id: id,
                routineType: routineType,
                outcome: outcome,
                at: at,
                scheduledAt: scheduledAt,
                snoozedUntil: snoozedUntil,
                waterMl: waterMl,
              ),
          withReferenceMapper: (p0) => p0
              .map(
                (e) => (
                  e.readTable<$ReminderEventsTable, ReminderEventRow>(table),
                  BaseReferences<_$AppDatabase, $ReminderEventsTable, ReminderEventRow>(db, table, e),
                ),
              )
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ReminderEventsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ReminderEventsTable,
      ReminderEventRow,
      $$ReminderEventsTableFilterComposer,
      $$ReminderEventsTableOrderingComposer,
      $$ReminderEventsTableAnnotationComposer,
      $$ReminderEventsTableCreateCompanionBuilder,
      $$ReminderEventsTableUpdateCompanionBuilder,
      (ReminderEventRow, BaseReferences<_$AppDatabase, $ReminderEventsTable, ReminderEventRow>),
      ReminderEventRow,
      PrefetchHooks Function()
    >;
typedef $$AppSettingsTableTableCreateCompanionBuilder = AppSettingsTableCompanion Function({
  Value<int> id,
  Value<String> themeVariant,
  Value<bool> precisionTiming,
  Value<int> waterPerTapMl,
});
typedef $$AppSettingsTableTableUpdateCompanionBuilder = AppSettingsTableCompanion Function({
  Value<int> id,
  Value<String> themeVariant,
  Value<bool> precisionTiming,
  Value<int> waterPerTapMl,
});

class $$AppSettingsTableTableFilterComposer extends Composer<_$AppDatabase, $AppSettingsTableTable> {
  $$AppSettingsTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get themeVariant =>
      $composableBuilder(column: $table.themeVariant, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get precisionTiming =>
      $composableBuilder(column: $table.precisionTiming, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get waterPerTapMl =>
      $composableBuilder(column: $table.waterPerTapMl, builder: (column) => ColumnFilters(column));
}

class $$AppSettingsTableTableOrderingComposer extends Composer<_$AppDatabase, $AppSettingsTableTable> {
  $$AppSettingsTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get themeVariant =>
      $composableBuilder(column: $table.themeVariant, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get precisionTiming =>
      $composableBuilder(column: $table.precisionTiming, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get waterPerTapMl =>
      $composableBuilder(column: $table.waterPerTapMl, builder: (column) => ColumnOrderings(column));
}

class $$AppSettingsTableTableAnnotationComposer extends Composer<_$AppDatabase, $AppSettingsTableTable> {
  $$AppSettingsTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id => $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get themeVariant =>
      $composableBuilder(column: $table.themeVariant, builder: (column) => column);

  GeneratedColumn<bool> get precisionTiming =>
      $composableBuilder(column: $table.precisionTiming, builder: (column) => column);

  GeneratedColumn<int> get waterPerTapMl =>
      $composableBuilder(column: $table.waterPerTapMl, builder: (column) => column);
}

class $$AppSettingsTableTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $AppSettingsTableTable,
          SettingsRow,
          $$AppSettingsTableTableFilterComposer,
          $$AppSettingsTableTableOrderingComposer,
          $$AppSettingsTableTableAnnotationComposer,
          $$AppSettingsTableTableCreateCompanionBuilder,
          $$AppSettingsTableTableUpdateCompanionBuilder,
          (SettingsRow, BaseReferences<_$AppDatabase, $AppSettingsTableTable, SettingsRow>),
          SettingsRow,
          PrefetchHooks Function()
        > {
  $$AppSettingsTableTableTableManager(_$AppDatabase db, $AppSettingsTableTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () => $$AppSettingsTableTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () => $$AppSettingsTableTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () => $$AppSettingsTableTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<String> themeVariant = const Value.absent(),
                Value<bool> precisionTiming = const Value.absent(),
                Value<int> waterPerTapMl = const Value.absent(),
              }) => AppSettingsTableCompanion(
                id: id,
                themeVariant: themeVariant,
                precisionTiming: precisionTiming,
                waterPerTapMl: waterPerTapMl,
              ),
          createCompanionCallback:
              ({
                Value<int> id = const Value.absent(),
                Value<String> themeVariant = const Value.absent(),
                Value<bool> precisionTiming = const Value.absent(),
                Value<int> waterPerTapMl = const Value.absent(),
              }) => AppSettingsTableCompanion.insert(
                id: id,
                themeVariant: themeVariant,
                precisionTiming: precisionTiming,
                waterPerTapMl: waterPerTapMl,
              ),
          withReferenceMapper: (p0) => p0
              .map(
                (e) => (
                  e.readTable<$AppSettingsTableTable, SettingsRow>(table),
                  BaseReferences<_$AppDatabase, $AppSettingsTableTable, SettingsRow>(db, table, e),
                ),
              )
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$AppSettingsTableTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $AppSettingsTableTable,
      SettingsRow,
      $$AppSettingsTableTableFilterComposer,
      $$AppSettingsTableTableOrderingComposer,
      $$AppSettingsTableTableAnnotationComposer,
      $$AppSettingsTableTableCreateCompanionBuilder,
      $$AppSettingsTableTableUpdateCompanionBuilder,
      (SettingsRow, BaseReferences<_$AppDatabase, $AppSettingsTableTable, SettingsRow>),
      SettingsRow,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$RoutinesTableTableManager get routines => $$RoutinesTableTableManager(_db, _db.routines);
  $$WorkWindowsTableTableManager get workWindows => $$WorkWindowsTableTableManager(_db, _db.workWindows);
  $$ReminderEventsTableTableManager get reminderEvents => $$ReminderEventsTableTableManager(_db, _db.reminderEvents);
  $$AppSettingsTableTableTableManager get appSettingsTable =>
      $$AppSettingsTableTableTableManager(_db, _db.appSettingsTable);
}
