// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Knight Rise';

  @override
  String get tagline => 'Stay Active. Stay Focused.';

  @override
  String get nextUp => 'Next up';

  @override
  String get offDuty => 'Off duty';

  @override
  String offDutyNext(String when) {
    return 'Back on duty $when';
  }

  @override
  String get dueNow => 'Due now';

  @override
  String snoozedUntil(String time) {
    return 'Snoozed until $time';
  }

  @override
  String get done => 'Done';

  @override
  String get claimBreak => 'Claim break';

  @override
  String get snooze10 => 'Snooze 10m';

  @override
  String get questLog => 'Today\'s quest';

  @override
  String get routineHydration => 'Hydration';

  @override
  String get routineStretch => 'Quick stretch';

  @override
  String get routineEyeRest => 'Eye rest';

  @override
  String waterToday(int ml) {
    return '$ml ml today';
  }

  @override
  String progressOf(int done, int target) {
    return '$done / $target';
  }

  @override
  String get themeMidnight => 'Midnight';

  @override
  String get themeAmoled => 'AMOLED';

  @override
  String get gallery => 'Widget gallery';

  @override
  String get disabled => 'Disabled';
}
